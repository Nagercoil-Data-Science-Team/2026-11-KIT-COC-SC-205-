"""
========================================================================
Research Implementation: Innovation of Northeast China Folk Customs
"Eight Oddities" in Packaging Design
========================================================================
Mixed-Methods Research | Synthetic Dataset (Clearly Labelled)
Author  : Research Pipeline
Version : 1.0
Date    : 2026-11-21

DISCLAIMER
----------
All participant data in this script are SYNTHETIC and generated solely
for pipeline testing.  They do NOT represent real survey responses,
expert opinions, or validated empirical findings.  Statistical results
are computed from the synthetic data using real algorithms.

========================================================================
"""

# ─────────────────────────────────────────────────────────────────────
# 0. IMPORTS & GLOBAL SETTINGS
# ─────────────────────────────────────────────────────────────────────
import os, sys, logging, pickle, warnings, datetime, json, re
import numpy as np
import pandas as pd
import scipy.stats as stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.gridspec as gridspec
import seaborn as sns
from pathlib import Path
from collections import Counter

from sklearn.preprocessing import LabelEncoder
from statsmodels.stats.outliers_influence import variance_inflation_factor
import statsmodels.api as sm
import statsmodels.formula.api as smf

from factor_analyzer import FactorAnalyzer, calculate_kmo, calculate_bartlett_sphericity

# ── Compatibility patch: factor_analyzer 0.5.x vs sklearn >= 1.6 ─────
# factor_analyzer calls check_array(force_all_finite=...) which was
# renamed to ensure_all_finite in scikit-learn 1.6+.  Patch the module.
try:
    import factor_analyzer.factor_analyzer as _fa_mod
    import sklearn.utils.validation as _skval
    _orig_ca = _skval.check_array
    def _patched_ca(*args, **kwargs):
        if "force_all_finite" in kwargs:
            val = kwargs.pop("force_all_finite")
            # "allow-nan" -> True for ensure_all_finite
            kwargs["ensure_all_finite"] = False if val == "allow-nan" else val
        return _orig_ca(*args, **kwargs)
    _fa_mod.check_array = _patched_ca
except Exception as _e:
    pass  # If the patch fails, let fa.fit() raise its own error
import semopy

warnings.filterwarnings("ignore")

# ── Matplotlib global settings ────────────────────────────────────────
plt.rcParams["figure.figsize"]  = (11, 7)
plt.rcParams["font.family"]     = "Times New Roman"
plt.rcParams["font.size"]       = 18
plt.rcParams["font.weight"]     = "bold"
plt.rcParams["axes.titleweight"]= "bold"
plt.rcParams["axes.labelweight"]= "bold"
DPI = 800

# ── Reproducibility ───────────────────────────────────────────────────
SEED = 42
np.random.seed(SEED)

# ── Paths ─────────────────────────────────────────────────────────────
BASE   = Path(__file__).parent
PATHS  = {
    "dataset"   : BASE / "dataset",
    "results"   : BASE / "results",
    "png"       : BASE / "figures" / "PNG",
    "tiff"      : BASE / "figures" / "TIFF",
    "qual"      : BASE / "qualitative_analysis",
    "models"    : BASE / "models",
    "logs"      : BASE / "logs",
}
for p in PATHS.values():
    p.mkdir(parents=True, exist_ok=True)

# ── Logging ───────────────────────────────────────────────────────────
LOG_FILE = PATHS["logs"] / "implementation_log.txt"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)
log.info("=" * 70)
log.info("Eight Oddities Packaging Design Research — Pipeline Start")
log.info("=" * 70)
log.info("NOTICE: Synthetic dataset — not real participant observations.")

# ═══════════════════════════════════════════════════════════════════════
# 1. CONSTRUCT & ITEM DEFINITIONS
# ═══════════════════════════════════════════════════════════════════════
CONSTRUCTS = {
    # Independent Variables
    "RD"  : {"name": "Regional Design",           "items": ["Q6",  "Q7"],               "role": "IV"},
    "AD"  : {"name": "Anthropomorphic Design",     "items": ["Q8",  "Q9"],               "role": "IV"},
    "ERD" : {"name": "Emotional Resonance Design", "items": ["Q10", "Q11"],              "role": "IV"},
    "SM"  : {"name": "Series Modelling",           "items": ["Q12", "Q13"],              "role": "IV"},
    # Dependent Variables
    "CI"  : {"name": "Cultural Identity",          "items": ["Q14", "Q15", "Q16"],       "role": "DV"},
    "CINT": {"name": "Consumer Interest",          "items": ["Q17", "Q18", "Q19"],       "role": "DV"},
    "CC"  : {"name": "Cultural Connection",        "items": ["Q20", "Q21"],              "role": "DV"},
    "VC"  : {"name": "Visual Consistency",         "items": ["Q22", "Q23"],              "role": "DV"},
    "PR"  : {"name": "Packaging Recognition",      "items": ["Q24", "Q25"],              "role": "DV"},
}

ITEM_LABELS = {
    "Q6" : "Local cultural motifs are clearly expressed in the packaging",
    "Q7" : "Regional symbols make the design distinctive",
    "Q8" : "Character figures on packaging feel relatable",
    "Q9" : "Anthropomorphic elements increase purchase intention",
    "Q10": "The packaging evokes emotional nostalgia",
    "Q11": "Emotional design strengthens my connection to the brand",
    "Q12": "The series packaging creates a coherent visual family",
    "Q13": "Series design encourages collecting behaviour",
    "Q14": "This packaging reflects my cultural identity",
    "Q15": "I feel proud when I see this regional packaging",
    "Q16": "The design represents Northeast China's heritage well",
    "Q17": "I am interested in purchasing this product",
    "Q18": "This packaging makes the product stand out",
    "Q19": "I would recommend this product to others",
    "Q20": "The packaging strengthens my cultural connection",
    "Q21": "It reminds me of Northeast Chinese traditions",
    "Q22": "The visual style is consistent across the product line",
    "Q23": "Design elements are harmoniously aligned",
    "Q24": "I can easily identify this brand's packaging",
    "Q25": "The packaging is memorable and recognisable",
}

ALL_ITEMS = [f"Q{i}" for i in range(6, 26)]   # Q6–Q25

HYPOTHESES = [
    {"id": "H1", "iv": "RD",  "dv": "CI",   "label": "Regional Design → Cultural Identity"},
    {"id": "H2", "iv": "AD",  "dv": "CINT", "label": "Anthropomorphic Design → Consumer Interest"},
    {"id": "H3", "iv": "ERD", "dv": "CC",   "label": "Emotional Resonance Design → Cultural Connection"},
    {"id": "H4a","iv": "SM",  "dv": "VC",   "label": "Series Modelling → Visual Consistency"},
    {"id": "H4b","iv": "SM",  "dv": "PR",   "label": "Series Modelling → Packaging Recognition"},
]

# ═══════════════════════════════════════════════════════════════════════
# 2. SYNTHETIC DATASET GENERATION
# ═══════════════════════════════════════════════════════════════════════

def generate_synthetic_data() -> pd.DataFrame:
    """
    Generate a clearly labelled synthetic dataset (n=350) that mimics
    realistic Likert-scale response distributions for a packaging-design
    survey.  Correlations are seeded so that IVs predict their DVs
    moderately-to-strongly (facilitating meaningful statistical tests).

    Returns
    -------
    pd.DataFrame
        Raw synthetic dataset with demographic and item columns.
    """
    log.info("--- Generating synthetic dataset (n=350) ---")
    n_local    = 250
    n_students = 100
    n_total    = n_local + n_students

    rng = np.random.default_rng(SEED)

    # ── Demographics ──────────────────────────────────────────────────
    # Group
    group = (["Local Resident"] * n_local) + (["University Student"] * n_students)

    # Age
    age_local   = rng.choice([1, 2, 3, 4, 5], n_local,
                             p=[0.08, 0.30, 0.35, 0.18, 0.09])
    age_student = rng.choice([1, 2, 3, 4, 5], n_students,
                             p=[0.40, 0.45, 0.10, 0.04, 0.01])
    age = np.concatenate([age_local, age_student])
    AGE_LABELS  = {1: "18–24", 2: "25–34", 3: "35–44", 4: "45–54", 5: "55+"}

    # Gender
    gender = rng.choice([1, 2, 3], n_total, p=[0.47, 0.50, 0.03])
    GENDER_LABELS = {1: "Male", 2: "Female", 3: "Other"}

    # Education
    edu_local   = rng.choice([1, 2, 3, 4], n_local,
                             p=[0.08, 0.35, 0.40, 0.17])
    edu_student = rng.choice([1, 2, 3, 4], n_students,
                             p=[0.02, 0.60, 0.33, 0.05])
    education = np.concatenate([edu_local, edu_student])
    EDU_LABELS = {1: "High School", 2: "Bachelor", 3: "Master", 4: "Doctoral"}

    # ── Latent factor generation for IVs ──────────────────────────────
    cov_iv = np.array([
        [1.00, 0.38, 0.35, 0.38],
        [0.38, 1.00, 0.38, 0.36],
        [0.35, 0.38, 1.00, 0.40],
        [0.38, 0.36, 0.40, 1.00]
    ])
    means_iv = [3.60, 3.50, 3.70, 3.60]
    iv_factors = rng.multivariate_normal(means_iv, cov_iv, n_total)
    RD_f, AD_f, ERD_f, SM_f = iv_factors.T

    # Generate IV items (Q6–Q13) with noise calibrated for alpha in [0.75, 0.85]
    s_iv = 0.58
    Q6 = np.clip(np.round(RD_f + rng.normal(0, s_iv, n_total)), 1, 5).astype(int)
    Q7 = np.clip(np.round(RD_f + rng.normal(0, s_iv, n_total)), 1, 5).astype(int)
    RD_score = (Q6 + Q7) / 2.0

    Q8 = np.clip(np.round(AD_f + rng.normal(0, s_iv, n_total)), 1, 5).astype(int)
    Q9 = np.clip(np.round(AD_f + rng.normal(0, s_iv, n_total)), 1, 5).astype(int)
    AD_score = (Q8 + Q9) / 2.0

    Q10 = np.clip(np.round(ERD_f + rng.normal(0, s_iv, n_total)), 1, 5).astype(int)
    Q11 = np.clip(np.round(ERD_f + rng.normal(0, s_iv, n_total)), 1, 5).astype(int)
    ERD_score = (Q10 + Q11) / 2.0

    Q12 = np.clip(np.round(SM_f + rng.normal(0, s_iv, n_total)), 1, 5).astype(int)
    Q13 = np.clip(np.round(SM_f + rng.normal(0, s_iv, n_total)), 1, 5).astype(int)
    SM_score = (Q12 + Q13) / 2.0

    # Helper function to generate DV items with targeted structural R² (0.75–0.85)
    def gen_dv_items(iv_score, beta_target, res_scale, item_noise, n_items):
        dv_latent = beta_target * (iv_score - iv_score.mean()) + iv_score.mean() + rng.normal(0, res_scale, n_total)
        items = []
        for _ in range(n_items):
            item = np.clip(np.round(dv_latent + rng.normal(0, item_noise, n_total)), 1, 5).astype(int)
            items.append(item)
        return items

    # Generate DV items (Q14–Q25)
    Q14, Q15, Q16 = gen_dv_items(RD_score, 0.88, 0.22, 0.65, 3)
    Q17, Q18, Q19 = gen_dv_items(AD_score, 0.87, 0.23, 0.65, 3)
    Q20, Q21      = gen_dv_items(ERD_score, 0.88, 0.22, 0.52, 2)
    Q22, Q23      = gen_dv_items(SM_score, 0.90, 0.16, 0.50, 2)
    Q24, Q25      = gen_dv_items(SM_score, 0.89, 0.17, 0.50, 2)

    item_data = {
        "Q6": Q6, "Q7": Q7, "Q8": Q8, "Q9": Q9,
        "Q10": Q10, "Q11": Q11, "Q12": Q12, "Q13": Q13,
        "Q14": Q14, "Q15": Q15, "Q16": Q16,
        "Q17": Q17, "Q18": Q18, "Q19": Q19,
        "Q20": Q20, "Q21": Q21, "Q22": Q22, "Q23": Q23,
        "Q24": Q24, "Q25": Q25,
    }

    # ── Demographic controls (Q1–Q5) ──────────────────────────────────
    df = pd.DataFrame({
        "ResponseID": range(1, n_total + 1),
        "SYNTHETIC_DATA_FLAG": True,          # explicit label
        "Group"     : group,
        "Q1_Age"    : age,
        "Q2_Gender" : gender,
        "Q3_Education": education,
        "Q4_Region" : rng.choice(
            [1, 2, 3, 4],  # 1=Liaoning 2=Jilin 3=Heilongjiang 4=Other
            n_total, p=[0.30, 0.28, 0.27, 0.15]),
        "Q5_Purchase_Freq": rng.choice(
            [1, 2, 3, 4, 5], n_total,
            p=[0.08, 0.20, 0.35, 0.25, 0.12]),
    })
    for col, arr in item_data.items():
        df[col] = arr

    df["Age_Label"]       = df["Q1_Age"].map(AGE_LABELS)
    df["Gender_Label"]    = df["Q2_Gender"].map(GENDER_LABELS)
    df["Education_Label"] = df["Q3_Education"].map(EDU_LABELS)

    log.info(f"  Synthetic dataset shape: {df.shape}")
    return df


# ═══════════════════════════════════════════════════════════════════════
# 3. DATA PREPROCESSING
# ═══════════════════════════════════════════════════════════════════════

def preprocess_data(df_raw: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """
    Clean and validate the raw dataset.

    Steps
    -----
    1. Missing-value identification and imputation (median).
    2. Duplicate response detection and removal.
    3. Invalid Likert-response flagging (outside 1–5).
    4. Demographic encoding.
    5. Straightlining (low variance) detection.
    6. Outlier detection (Mahalanobis distance).
    7. Descriptive quality logs.

    Returns
    -------
    df_clean : pd.DataFrame
    report   : dict  — data quality summary
    """
    log.info("=" * 60)
    log.info("STAGE 3: DATA PREPROCESSING")
    log.info("=" * 60)
    df = df_raw.copy()
    report = {}

    # ── 3.1 Missing values ────────────────────────────────────────────
    missing_before = df[ALL_ITEMS].isnull().sum().sum()
    for col in ALL_ITEMS:
        if df[col].isnull().any():
            df[col].fillna(int(df[col].median()), inplace=True)
    report["missing_before"] = int(missing_before)
    report["missing_after"]  = int(df[ALL_ITEMS].isnull().sum().sum())
    log.info(f"  Missing values: {missing_before} identified, imputed with median")

    # ── 3.2 Duplicate detection ───────────────────────────────────────
    dup_mask = df.duplicated(subset=ALL_ITEMS, keep="first")
    n_dup    = dup_mask.sum()
    df       = df[~dup_mask].reset_index(drop=True)
    report["duplicates_removed"] = int(n_dup)
    log.info(f"  Duplicates removed: {n_dup}")

    # ── 3.3 Invalid Likert values ─────────────────────────────────────
    invalid_mask = ((df[ALL_ITEMS] < 1) | (df[ALL_ITEMS] > 5)).any(axis=1)
    n_invalid    = invalid_mask.sum()
    df           = df[~invalid_mask].reset_index(drop=True)
    report["invalid_responses"] = int(n_invalid)
    log.info(f"  Invalid Likert responses removed: {n_invalid}")

    # ── 3.4 Straightlining detection (variance = 0 across all items) ──
    item_var = df[ALL_ITEMS].var(axis=1)
    straight = (item_var == 0).sum()
    report["straightliners"] = int(straight)
    log.info(f"  Straightlining respondents detected: {straight}")

    # ── 3.5 Outlier detection (Mahalanobis distance) ──────────────────
    X = df[ALL_ITEMS].values.astype(float)
    try:
        cov    = np.cov(X, rowvar=False)
        inv_cov= np.linalg.pinv(cov)
        mean_v = X.mean(axis=0)
        diff   = X - mean_v
        maha   = np.sqrt(np.einsum("ij,jk,ik->i", diff, inv_cov, diff))
        chi2_thresh = stats.chi2.ppf(0.999, df=len(ALL_ITEMS))
        outlier_mask= (maha ** 2) > chi2_thresh
        n_outliers  = outlier_mask.sum()
    except Exception:
        n_outliers   = 0
        outlier_mask = np.zeros(len(df), dtype=bool)
    report["outliers_mahalanobis"] = int(n_outliers)
    log.info(f"  Mahalanobis outliers (p<0.001): {n_outliers} (retained for analysis)")

    # ── 3.6 Demographic encoding ──────────────────────────────────────
    le = LabelEncoder()
    df["Group_Enc"] = le.fit_transform(df["Group"])

    # ── 3.7 Construct composite scores ───────────────────────────────
    for code, meta in CONSTRUCTS.items():
        df[f"{code}_Score"] = df[meta["items"]].mean(axis=1)

    report["final_n"]   = len(df)
    report["item_cols"] = ALL_ITEMS
    log.info(f"  Final cleaned sample size: {len(df)}")

    return df, report


# ═══════════════════════════════════════════════════════════════════════
# 4. DESCRIPTIVE STATISTICS
# ═══════════════════════════════════════════════════════════════════════

def descriptive_statistics(df: pd.DataFrame) -> dict:
    log.info("=" * 60)
    log.info("STAGE 4: DESCRIPTIVE STATISTICS")
    log.info("=" * 60)

    # ── Demographic frequencies ───────────────────────────────────────
    demo_tables = {}
    for col, label_col, title in [
        ("Q1_Age",       "Age_Label",       "Age Group"),
        ("Q2_Gender",    "Gender_Label",    "Gender"),
        ("Q3_Education", "Education_Label", "Education Level"),
        ("Group",        "Group",           "Participant Group"),
    ]:
        lc = label_col if label_col in df.columns else col
        freq  = df[lc].value_counts()
        pct   = (freq / len(df) * 100).round(2)
        tbl   = pd.DataFrame({"Frequency": freq, "Percentage (%)": pct}).reset_index()
        tbl.columns = [title, "Frequency", "Percentage (%)"]
        demo_tables[title] = tbl
        log.info(f"  {title}:\n{tbl.to_string(index=False)}")

    # ── Item-level descriptives ───────────────────────────────────────
    desc_rows = []
    for item in ALL_ITEMS:
        vals = df[item]
        # find construct
        cname = next(
            (CONSTRUCTS[c]["name"] for c, m in CONSTRUCTS.items() if item in m["items"]),
            "Unknown",
        )
        desc_rows.append({
            "Item"     : item,
            "Construct": cname,
            "Label"    : ITEM_LABELS[item],
            "Mean"     : round(vals.mean(), 3),
            "SD"       : round(vals.std(), 3),
            "Min"      : int(vals.min()),
            "Max"      : int(vals.max()),
            "Skewness" : round(vals.skew(), 3),
            "Kurtosis" : round(vals.kurt(), 3),
        })
    desc_df = pd.DataFrame(desc_rows)
    log.info(f"  Item descriptives computed for {len(ALL_ITEMS)} items")

    return {"demographic": demo_tables, "item_descriptives": desc_df}


# ═══════════════════════════════════════════════════════════════════════
# 5. RELIABILITY ANALYSIS — CRONBACH'S ALPHA
# ═══════════════════════════════════════════════════════════════════════

def cronbach_alpha(item_matrix: np.ndarray) -> float:
    """Compute Cronbach's alpha from item score matrix (n×k)."""
    k     = item_matrix.shape[1]
    item_vars  = item_matrix.var(axis=0, ddof=1)
    total_var  = item_matrix.sum(axis=1).var(ddof=1)
    alpha = (k / (k - 1)) * (1 - item_vars.sum() / total_var)
    return float(np.clip(alpha, 0, 1))


def reliability_analysis(df: pd.DataFrame) -> pd.DataFrame:
    log.info("=" * 60)
    log.info("STAGE 5: RELIABILITY ANALYSIS (CRONBACH'S ALPHA)")
    log.info("=" * 60)
    rows = []
    for code, meta in CONSTRUCTS.items():
        mat   = df[meta["items"]].values.astype(float)
        alpha = cronbach_alpha(mat)
        flag  = ("✓ Acceptable" if alpha >= 0.70 else "✗ Below threshold")
        rows.append({
            "Construct"       : meta["name"],
            "Code"            : code,
            "Role"            : meta["role"],
            "No. Items"       : len(meta["items"]),
            "Cronbach's Alpha": round(alpha, 3),
            "Status"          : flag,
        })
        log.info(f"  {code} ({meta['name']}): α = {alpha:.3f} {flag}")
    return pd.DataFrame(rows)


# ═══════════════════════════════════════════════════════════════════════
# 6. EXPLORATORY FACTOR ANALYSIS (EFA)
# ═══════════════════════════════════════════════════════════════════════

def run_efa(df: pd.DataFrame) -> dict:
    log.info("=" * 60)
    log.info("STAGE 6: EXPLORATORY FACTOR ANALYSIS (EFA)")
    log.info("=" * 60)

    X = df[ALL_ITEMS].values.astype(float)

    # ── KMO & Bartlett ────────────────────────────────────────────────
    kmo_all, kmo_model = calculate_kmo(X)
    bartlett_chi2, bartlett_p = calculate_bartlett_sphericity(X)
    log.info(f"  KMO measure: {kmo_model:.3f}")
    log.info(f"  Bartlett χ²: {bartlett_chi2:.3f}, p = {bartlett_p:.4f}")

    kmo_bartlett = pd.DataFrame({
        "Test"      : ["KMO Measure of Sampling Adequacy", "Bartlett's Test: χ²", "Bartlett's Test: p-value"],
        "Value"     : [round(kmo_model, 3), round(bartlett_chi2, 3), f"{bartlett_p:.4e}"],
        "Adequacy"  : [
            "Meritorious (≥0.80)" if kmo_model >= 0.80 else "Acceptable (≥0.60)",
            "Significant" if bartlett_p < 0.05 else "Not Significant",
            "p < 0.001" if bartlett_p < 0.001 else f"p = {bartlett_p:.4f}",
        ],
    })

    # ── EFA with 4 factors (matching 4 IVs) ──────────────────────────
    n_factors = 4
    fa = FactorAnalyzer(n_factors=n_factors, rotation="oblimin", method="ml")
    fa.fit(X)

    loadings_df = pd.DataFrame(
        fa.loadings_,
        index=ALL_ITEMS,
        columns=[f"Factor {i+1}" for i in range(n_factors)],
    )
    loadings_df.index.name = "Item"
    loadings_df = loadings_df.round(3)

    ev, v = fa.get_eigenvalues()
    variance_df = pd.DataFrame({
        "Factor"              : [f"Factor {i+1}" for i in range(n_factors)],
        "Eigenvalue"          : ev[:n_factors].round(3),
        "Variance Explained (%)" : (fa.get_factor_variance()[1] * 100).round(2),
        "Cumulative (%)"      : (fa.get_factor_variance()[2] * 100).round(2),
    })
    log.info(f"  Variance explained:\n{variance_df.to_string(index=False)}")

    return {
        "fa"          : fa,
        "loadings"    : loadings_df,
        "variance"    : variance_df,
        "kmo_bartlett": kmo_bartlett,
        "kmo_model"   : kmo_model,
        "bartlett_chi2": bartlett_chi2,
        "bartlett_p"  : bartlett_p,
    }


# ═══════════════════════════════════════════════════════════════════════
# 7. CONFIRMATORY FACTOR ANALYSIS (CFA) & CONVERGENT/DISCRIMINANT VALIDITY
# ═══════════════════════════════════════════════════════════════════════

def run_cfa(df: pd.DataFrame, reliability_df: pd.DataFrame) -> dict:
    log.info("=" * 60)
    log.info("STAGE 7: CONFIRMATORY FACTOR ANALYSIS (CFA)")
    log.info("=" * 60)

    # ── Build semopy model string ─────────────────────────────────────
    model_desc_lines = []
    for code, meta in CONSTRUCTS.items():
        items_str = " + ".join(meta["items"])
        model_desc_lines.append(f"{code} =~ {items_str}")
    model_desc = "\n".join(model_desc_lines)
    log.info(f"  CFA model:\n{model_desc}")

    model = semopy.Model(model_desc)
    try:
        res = model.fit(df[ALL_ITEMS])
        fit_stats = semopy.calc_stats(model)
        cfa_fitted = True
        log.info("  CFA model converged.")
    except Exception as e:
        log.warning(f"  CFA did not converge fully: {e}")
        fit_stats  = None
        cfa_fitted = False

    # ── Composite Reliability (CR) & AVE ─────────────────────────────
    cr_ave_rows = []
    for code, meta in CONSTRUCTS.items():
        items  = meta["items"]
        mat    = df[items].values.astype(float)
        # Standardised loadings via correlation-based approximation
        corr_mat = np.corrcoef(mat.T)
        mean_load= np.mean(np.abs(np.triu(corr_mat, 1)))
        # Approximate loadings from cronbach: λ ≈ sqrt(alpha)
        alpha    = cronbach_alpha(mat)
        lam      = np.sqrt(max(alpha, 0.001))
        k        = len(items)
        # CR = (Σλ)² / [(Σλ)² + Σ(1-λ²)]
        sum_lam  = k * lam
        sum_err  = k * (1 - lam ** 2)
        cr       = (sum_lam ** 2) / ((sum_lam ** 2) + sum_err)
        # AVE = Σλ² / k
        ave      = (lam ** 2 * k) / k
        cr_ave_rows.append({
            "Construct": meta["name"],
            "Code"     : code,
            "No. Items": k,
            "Cronbach α": round(alpha, 3),
            "CR"        : round(cr, 3),
            "AVE"       : round(ave, 3),
            "CR ≥ 0.70" : "✓" if cr >= 0.70 else "✗",
            "AVE ≥ 0.50": "✓" if ave >= 0.50 else "✗",
        })

    cr_ave_df = pd.DataFrame(cr_ave_rows)
    log.info(f"  CR/AVE table:\n{cr_ave_df[['Code','CR','AVE']].to_string(index=False)}")

    # ── Discriminant Validity: Fornell-Larcker ────────────────────────
    codes  = list(CONSTRUCTS.keys())
    fl_mat = pd.DataFrame(np.nan, index=codes, columns=codes)
    for code in codes:
        ave = cr_ave_df.loc[cr_ave_df["Code"] == code, "AVE"].values[0]
        fl_mat.loc[code, code] = round(np.sqrt(ave), 3)
    # Off-diagonal: Pearson correlation between composite scores
    for i, ci in enumerate(codes):
        for j, cj in enumerate(codes):
            if i > j:
                r = df[f"{ci}_Score"].corr(df[f"{cj}_Score"])
                fl_mat.loc[ci, cj] = round(r, 3)
                fl_mat.loc[cj, ci] = round(r, 3)
    fl_mat.index.name = "Construct"

    # ── HTMT ──────────────────────────────────────────────────────────
    htmt_rows = []
    for i, ci in enumerate(codes):
        for j, cj in enumerate(codes):
            if i < j:
                items_i  = df[CONSTRUCTS[ci]["items"]].values
                items_j  = df[CONSTRUCTS[cj]["items"]].values
                # HTMT = mean(cross-loadings) / sqrt(mean(within_i) * mean(within_j))
                cross    = np.mean([
                    abs(np.corrcoef(items_i[:, m], items_j[:, n])[0, 1])
                    for m in range(items_i.shape[1])
                    for n in range(items_j.shape[1])
                ])
                wi       = np.mean([
                    abs(np.corrcoef(items_i[:, m], items_i[:, n])[0, 1])
                    for m in range(items_i.shape[1])
                    for n in range(items_i.shape[1]) if m != n
                ]) if items_i.shape[1] > 1 else 1.0
                wj       = np.mean([
                    abs(np.corrcoef(items_j[:, m], items_j[:, n])[0, 1])
                    for m in range(items_j.shape[1])
                    for n in range(items_j.shape[1]) if m != n
                ]) if items_j.shape[1] > 1 else 1.0
                denom    = np.sqrt(wi * wj) if wi > 0 and wj > 0 else 1.0
                htmt_val = cross / denom if denom > 0 else np.nan
                htmt_rows.append({
                    "Construct A": ci,
                    "Construct B": cj,
                    "HTMT"       : round(htmt_val, 3),
                    "< 0.90"     : "✓" if htmt_val < 0.90 else "✗",
                    "< 0.85 (strict)": "✓" if htmt_val < 0.85 else "✗",
                })
    htmt_df = pd.DataFrame(htmt_rows)

    # ── CFA fit indices ───────────────────────────────────────────────
    if fit_stats is not None and len(fit_stats) > 0:
        try:
            fit_df = pd.DataFrame(fit_stats).reset_index()
            fit_df.columns = ["Statistic", "Value"]
        except Exception:
            fit_df = pd.DataFrame({"Statistic": ["Model Status"], "Value": ["Converged"]})
    else:
        fit_df = pd.DataFrame({"Statistic": ["Model Status"], "Value": ["Estimated"]})

    return {
        "model"       : model if cfa_fitted else None,
        "cr_ave"      : cr_ave_df,
        "fl_matrix"   : fl_mat,
        "htmt"        : htmt_df,
        "fit_indices" : fit_df,
    }


# ═══════════════════════════════════════════════════════════════════════
# 8. PEARSON CORRELATION ANALYSIS
# ═══════════════════════════════════════════════════════════════════════

def correlation_analysis(df: pd.DataFrame) -> dict:
    log.info("=" * 60)
    log.info("STAGE 8: PEARSON CORRELATION ANALYSIS")
    log.info("=" * 60)

    score_cols = [f"{c}_Score" for c in CONSTRUCTS]
    corr_mat   = df[score_cols].corr(method="pearson").round(3)
    # Rename columns for readability
    name_map = {f"{c}_Score": c for c in CONSTRUCTS}
    corr_mat = corr_mat.rename(columns=name_map, index=name_map)

    # p-values
    n       = len(df)
    p_mat   = pd.DataFrame(np.nan, index=corr_mat.index, columns=corr_mat.columns)
    for c1 in corr_mat.columns:
        for c2 in corr_mat.columns:
            if c1 != c2:
                r = corr_mat.loc[c1, c2]
                t = r * np.sqrt((n - 2) / (1 - r ** 2 + 1e-12))
                p = 2 * stats.t.sf(abs(t), df=n - 2)
                p_mat.loc[c1, c2] = round(p, 4)

    log.info(f"  Correlation matrix computed for {len(score_cols)} constructs")
    return {"corr_matrix": corr_mat, "p_matrix": p_mat}


# ═══════════════════════════════════════════════════════════════════════
# 9. MULTIPLE REGRESSION & HYPOTHESIS TESTING
# ═══════════════════════════════════════════════════════════════════════

def regression_and_hypothesis(df: pd.DataFrame) -> dict:
    log.info("=" * 60)
    log.info("STAGE 9: REGRESSION & HYPOTHESIS TESTING")
    log.info("=" * 60)

    hyp_rows   = []
    reg_rows   = []
    vif_rows   = []
    model_perf = []

    # ── All-IV model for overall R² benchmarking ──────────────────────
    iv_scores  = [f"{c}_Score" for c in ["RD", "AD", "ERD", "SM"]]

    for hyp in HYPOTHESES:
        iv_col = f"{hyp['iv']}_Score"
        dv_col = f"{hyp['dv']}_Score"

        y = df[dv_col].values
        X_sm = sm.add_constant(df[iv_col].values)

        try:
            ols  = sm.OLS(y, X_sm).fit()
            beta = ols.params[1]
            se   = ols.bse[1]
            t    = ols.tvalues[1]
            p    = ols.pvalues[1]
            r2   = ols.rsquared
            r2_adj = ols.rsquared_adj
            f_stat = ols.fvalue
            f_p    = ols.f_pvalue
        except Exception as e:
            log.warning(f"  Regression failed for {hyp['id']}: {e}")
            beta = se = t = p = r2 = r2_adj = f_stat = f_p = np.nan

        decision = "Supported" if (not np.isnan(p) and p < 0.05 and beta > 0) else "Not Supported"

        hyp_rows.append({
            "Hypothesis"       : hyp["id"],
            "Independent Variable": CONSTRUCTS[hyp["iv"]]["name"],
            "Dependent Variable"  : CONSTRUCTS[hyp["dv"]]["name"],
            "Std. Beta (β)"    : round(beta, 3),
            "Std. Error"       : round(se, 3),
            "t-statistic"      : round(t, 3),
            "p-value"          : round(p, 4),
            "R²"               : round(r2, 3),
            "Decision"         : decision,
        })
        model_perf.append({
            "Hypothesis": hyp["id"],
            "R²"        : round(r2, 3),
            "Adj. R²"   : round(r2_adj, 3),
            "F-statistic": round(f_stat, 3),
            "p (F)"     : round(f_p, 4),
            "Decision"  : decision,
        })

        log.info(f"  {hyp['id']}: β={beta:.3f}, t={t:.3f}, p={p:.4f}, R²={r2:.3f} → {decision}")

    # ── Full model: all IVs → each DV (for regression table) ──────────
    for dv_code in ["CI", "CINT", "CC", "VC", "PR"]:
        y     = df[f"{dv_code}_Score"].values
        X_all = df[iv_scores].values
        X_sm  = sm.add_constant(X_all)
        try:
            ols = sm.OLS(y, X_sm).fit()
            for idx, iv in enumerate(["RD", "AD", "ERD", "SM"]):
                reg_rows.append({
                    "DV"       : CONSTRUCTS[dv_code]["name"],
                    "IV"       : CONSTRUCTS[iv]["name"],
                    "Beta"     : round(ols.params[idx + 1], 3),
                    "SE"       : round(ols.bse[idx + 1], 3),
                    "t"        : round(ols.tvalues[idx + 1], 3),
                    "p"        : round(ols.pvalues[idx + 1], 4),
                    "R²"       : round(ols.rsquared, 3),
                    "Adj. R²"  : round(ols.rsquared_adj, 3),
                })

            # VIF
            for idx, iv in enumerate(iv_scores):
                vif_val = variance_inflation_factor(X_sm, idx + 1)
                vif_rows.append({
                    "DV"       : CONSTRUCTS[dv_code]["name"],
                    "IV"       : CONSTRUCTS[iv_scores.index(iv)]["name"] if iv_scores.index(iv) < 9 else iv,
                    "VIF"      : round(vif_val, 3),
                    "Tolerance": round(1 / vif_val, 3),
                    "Status"   : "✓ OK" if vif_val < 5 else "⚠ High",
                })
        except Exception as e:
            log.warning(f"  Full-model regression failed for {dv_code}: {e}")

    return {
        "hypothesis"   : pd.DataFrame(hyp_rows),
        "regression"   : pd.DataFrame(reg_rows),
        "vif"          : pd.DataFrame(vif_rows),
        "model_perf"   : pd.DataFrame(model_perf),
    }


# ═══════════════════════════════════════════════════════════════════════
# 10. QUALITATIVE ANALYSIS (SYNTHETIC INTERVIEW TRANSCRIPTS)
# ═══════════════════════════════════════════════════════════════════════

EXPERT_TRANSCRIPTS = [
    # 15 synthetic expert interview excerpts — clearly synthetic
    "The use of regional motifs such as the Northeast tiger and soybean patterns creates a strong sense of local identity in packaging. Traditional colour palettes—predominantly red and gold—reinforce cultural pride.",
    "Anthropomorphic characters modelled on folk figures from Manchurian heritage make the packaging relatable, particularly for younger consumers who grew up with these stories.",
    "Packaging that evokes emotional nostalgia, through references to winter landscapes and harvest festivals, creates a deeper bond between consumer and product. This emotional resonance is key to cultural preservation.",
    "Series packaging with consistent design language allows collectors to form a visual narrative. This modelling approach increases brand recognition across the product line.",
    "The Eight Oddities—long eggplants, big onions, and others—are powerful visual anchors. When translated into packaging, they communicate authentic regional identity.",
    "Traditional symbols like the Northeast kang (heated bed platform) and horse-drawn cart evoke cultural memories and differentiate the packaging in a crowded market.",
    "Colour symbolism is critical: dark red represents warmth and community in Northeast culture, while deep blue conveys the harsh winters. Packaging that uses these purposefully resonates emotionally.",
    "The integration of folk opera imagery (Errenzhuan) into packaging character design creates an immediate cultural shortcut for consumers familiar with this art form.",
    "Visual consistency across a product series is not just an aesthetic choice—it signals brand reliability and cultural coherence. Consumers trust series-designed packaging more.",
    "Packaging innovation should not sever ties with tradition. The most successful designs I have evaluated maintain cultural authenticity while incorporating modern production techniques.",
    "The folk custom motifs act as semiotic markers of regional origin. When consumers see these symbols, they form immediate associations with quality and heritage.",
    "Emotional resonance design goes beyond aesthetics. It taps into shared cultural memory, creating a sense of belonging that influences repeat purchase behaviour.",
    "Anthropomorphic design is particularly effective when the character's visual language aligns with the product's origin story, reinforcing authenticity and narrative coherence.",
    "The challenge for packaging designers is to balance innovation with cultural respect. Over-modernisation risks alienating heritage consumers, while strict traditionalism may not attract younger buyers.",
    "Series modelling in folk-themed packaging creates a collector culture, which significantly extends the product's brand equity beyond its functional value.",
]

THEME_DEFINITIONS = {
    "Northeast Regional Cultural Identity": [
        "regional", "motif", "local", "northeast", "manchurian", "manchuria",
        "heritage", "origin", "place", "provincial", "identity",
    ],
    "Anthropomorphic Packaging Design": [
        "anthropomorphic", "character", "figure", "folk", "relatable",
        "persona", "humanised", "face", "creature",
    ],
    "Emotional Resonance": [
        "emotional", "nostalgia", "nostalgic", "bond", "resonance",
        "feeling", "memory", "pride", "belonging", "evoke",
    ],
    "Series Modelling & Visual Consistency": [
        "series", "consistent", "consistency", "modelling", "collect",
        "collector", "narrative", "visual", "coherent",
    ],
    "Traditional Colours & Symbols": [
        "colour", "color", "red", "gold", "blue", "symbol",
        "pattern", "palette", "kang", "tiger", "soybean",
    ],
    "Packaging Innovation & Cultural Preservation": [
        "innovation", "innovative", "preserve", "preservation",
        "authentic", "authenticity", "modern", "tradition", "traditional",
        "balance", "heritage",
    ],
}


def qualitative_analysis() -> dict:
    log.info("=" * 60)
    log.info("STAGE 10: QUALITATIVE ANALYSIS")
    log.info("=" * 60)
    log.info("  NOTE: Interview transcripts are SYNTHETIC for pipeline testing.")

    all_text = " ".join(EXPERT_TRANSCRIPTS).lower()

    # ── Text preprocessing ────────────────────────────────────────────
    tokens = re.findall(r"\b[a-zA-Z]{3,}\b", all_text)
    stopwords = {
        "the", "and", "for", "are", "that", "this", "with", "their",
        "from", "which", "into", "when", "they", "them", "these", "its",
        "not", "more", "can", "also", "such", "been", "have", "make",
        "while", "most", "particularly", "through", "creates", "allows",
        "between", "particularly", "beyond", "across",
    }
    filtered_tokens = [t for t in tokens if t not in stopwords]
    freq_counter    = Counter(filtered_tokens)

    # ── Theme coding ──────────────────────────────────────────────────
    theme_rows = []
    code_rows  = []
    cultural_elements = []

    for theme, keywords in THEME_DEFINITIONS.items():
        count = sum(freq_counter.get(kw, 0) for kw in keywords)
        theme_rows.append({
            "Theme"    : theme,
            "Keywords" : ", ".join(keywords[:6]),
            "Frequency": count,
            "Subthemes": _get_subthemes(theme),
        })
        for kw in keywords:
            if freq_counter[kw] > 0:
                code_rows.append({
                    "Code"    : kw.title(),
                    "Theme"   : theme,
                    "Count"   : freq_counter[kw],
                })
        if "Cultural" in theme or "Symbol" in theme:
            cultural_elements.append({
                "Element"   : theme,
                "Frequency" : count,
                "Category"  : "Cultural",
            })

    # Top-25 keyword frequencies
    top_kw = pd.DataFrame(freq_counter.most_common(25),
                          columns=["Keyword", "Frequency"])

    theme_df    = pd.DataFrame(theme_rows).sort_values("Frequency", ascending=False)
    code_df     = pd.DataFrame(code_rows).sort_values("Count", ascending=False)
    cultural_df = pd.DataFrame(cultural_elements)

    log.info(f"  Themes identified: {len(theme_rows)}")
    log.info(f"  Top keywords: {freq_counter.most_common(5)}")

    return {
        "theme_df"      : theme_df,
        "code_df"       : code_df,
        "top_keywords"  : top_kw,
        "cultural_df"   : cultural_df,
    }


def _get_subthemes(theme: str) -> str:
    sub = {
        "Northeast Regional Cultural Identity":
            "Local Symbols; Regional Pride; Place Identity",
        "Anthropomorphic Packaging Design":
            "Folk Characters; Relatable Figures; Cultural Personas",
        "Emotional Resonance":
            "Nostalgia; Cultural Memory; Belonging",
        "Series Modelling & Visual Consistency":
            "Visual Coherence; Collector Culture; Brand Unity",
        "Traditional Colours & Symbols":
            "Colour Symbolism; Pattern Language; Iconic Motifs",
        "Packaging Innovation & Cultural Preservation":
            "Modern Tradition Balance; Heritage Innovation; Authenticity",
    }
    return sub.get(theme, "")


# ═══════════════════════════════════════════════════════════════════════
# 11. FIGURES
# ═══════════════════════════════════════════════════════════════════════

def save_fig(name: str):
    """Save figure to both PNG and TIFF at DPI=800."""
    for fmt, folder in [("png", PATHS["png"]), ("tiff", PATHS["tiff"])]:
        path = folder / f"{name}.{fmt}"
        plt.savefig(path, dpi=DPI, bbox_inches="tight",
                    format=fmt, facecolor="white")
    log.info(f"  Saved figure: {name}")


def fig01_demographics(demo_tables: dict):
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    colors    = ["#C0392B", "#2980B9", "#27AE60", "#F39C12",
                 "#8E44AD", "#16A085"]

    for ax, (title, tbl) in zip(axes.flatten(), demo_tables.items()):
        col_name = tbl.columns[0]
        labels   = tbl[col_name].astype(str)
        values   = tbl["Frequency"].values
        bars     = ax.bar(labels, values,
                          color=colors[:len(labels)], edgecolor="black", linewidth=0.8)
        ax.set_title(title, fontweight="bold", fontsize=16, pad=10)
        ax.set_ylabel("Frequency", fontweight="bold", fontsize=14)
        ax.set_xlabel(col_name, fontweight="bold", fontsize=14)
        ax.grid(False)
        for b in bars:
            ax.text(b.get_x() + b.get_width() / 2,
                    b.get_height() + 0.5,
                    str(int(b.get_height())),
                    ha="center", va="bottom", fontsize=12, fontweight="bold")
        ax.tick_params(axis="x", rotation=20, labelsize=11)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

    fig.suptitle("Demographic Distribution of Survey Participants",
                 fontsize=20, fontweight="bold", y=1.01)
    plt.tight_layout()
    save_fig("Fig01_Demographic_Distribution")
    plt.close()


def fig02_descriptives(desc_df: pd.DataFrame):
    fig, axes = plt.subplots(1, 2, figsize=(16, 8))
    ax1, ax2  = axes

    # Mean by item
    colors = plt.cm.RdYlGn(np.linspace(0.3, 0.9, len(desc_df)))
    bars   = ax1.barh(desc_df["Item"], desc_df["Mean"],
                      color=colors, edgecolor="black", linewidth=0.6)
    ax1.set_xlabel("Mean Score (1–5 Likert)", fontweight="bold", fontsize=14)
    ax1.set_title("Item Mean Scores", fontweight="bold", fontsize=16)
    ax1.set_xlim(1, 5)
    ax1.axvline(3.0, color="grey", linestyle="--", linewidth=1.2, label="Neutral (3.0)")
    ax1.legend(fontsize=12)
    ax1.grid(False)
    ax1.spines["top"].set_visible(False)
    ax1.spines["right"].set_visible(False)

    # SD by item
    ax2.barh(desc_df["Item"], desc_df["SD"],
             color="#2980B9", edgecolor="black", linewidth=0.6)
    ax2.set_xlabel("Standard Deviation", fontweight="bold", fontsize=14)
    ax2.set_title("Item Standard Deviations", fontweight="bold", fontsize=16)
    ax2.grid(False)
    ax2.spines["top"].set_visible(False)
    ax2.spines["right"].set_visible(False)

    fig.suptitle("Descriptive Statistics of Survey Items",
                 fontsize=20, fontweight="bold")
    plt.tight_layout()
    save_fig("Fig02_Descriptive_Statistics")
    plt.close()


def fig03_cronbach(rel_df: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(12, 7))
    colors  = ["#27AE60" if a >= 0.75 else "#F39C12" if a >= 0.70 else "#C0392B"
               for a in rel_df["Cronbach's Alpha"]]
    alpha_col = "Cronbach's Alpha"
    labels  = [str(row["Code"]) + "\n(" + str(row[alpha_col]) + ")"
               for _, row in rel_df.iterrows()]
    bars    = ax.bar(labels, rel_df["Cronbach's Alpha"],
                     color=colors, edgecolor="black", linewidth=0.8, width=0.6)
    ax.axhline(0.70, color="#C0392B", linestyle="--", linewidth=1.5, label="Threshold (α=0.70)")
    ax.axhline(0.75, color="#F39C12", linestyle="--", linewidth=1.5, label="Desired lower (0.75)")
    ax.axhline(0.85, color="#27AE60", linestyle="--", linewidth=1.5, label="Desired upper (0.85)")
    ax.set_ylim(0.5, 1.0)
    ax.set_ylabel("Cronbach's Alpha (α)", fontweight="bold", fontsize=15)
    ax.set_title("Cronbach's Alpha Reliability Comparison by Construct",
                 fontweight="bold", fontsize=17)
    ax.legend(fontsize=12, loc="lower right")
    ax.grid(False)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    for b, v in zip(bars, rel_df["Cronbach's Alpha"]):
        ax.text(b.get_x() + b.get_width() / 2,
                v + 0.005, f"{v:.3f}",
                ha="center", va="bottom", fontsize=12, fontweight="bold")
    plt.tight_layout()
    save_fig("Fig03_Cronbach_Alpha")
    plt.close()


def fig04_kmo_bartlett(efa_res: dict):
    fig, axes = plt.subplots(1, 2, figsize=(14, 7))

    # KMO gauge
    ax = axes[0]
    kmo = efa_res["kmo_model"]
    thresholds = [0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
    colors     = ["#C0392B", "#E67E22", "#F1C40F", "#27AE60", "#2980B9"]
    labels_kmo = ["Unacceptable\n(<0.6)", "Mediocre\n(0.6–0.7)",
                  "Middling\n(0.7–0.8)", "Meritorious\n(0.8–0.9)", "Marvellous\n(≥0.9)"]
    bottoms = [0] * 5
    for i in range(5):
        ax.bar(i, thresholds[i + 1] - thresholds[i],
               bottom=thresholds[i], color=colors[i],
               edgecolor="black", linewidth=0.8, alpha=0.75)
        ax.text(i, (thresholds[i] + thresholds[i + 1]) / 2,
                labels_kmo[i], ha="center", va="center",
                fontsize=10, fontweight="bold")
    ax.axhline(kmo, color="black", linestyle="-", linewidth=3,
               label=f"KMO = {kmo:.3f}")
    ax.set_xticks([])
    ax.set_ylabel("KMO Value", fontweight="bold", fontsize=14)
    ax.set_title("KMO Measure of Sampling Adequacy",
                 fontweight="bold", fontsize=15)
    ax.legend(fontsize=13, loc="upper right")
    ax.grid(False)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # Bartlett bar
    ax2 = axes[1]
    chi2  = efa_res["bartlett_chi2"]
    p_val = efa_res["bartlett_p"]
    ax2.bar(["Bartlett's χ²"], [chi2],
            color="#2980B9" if p_val < 0.05 else "#C0392B",
            edgecolor="black", linewidth=0.8, width=0.4)
    ax2.set_ylabel("χ² Statistic", fontweight="bold", fontsize=14)
    ax2.set_title(f"Bartlett's Test of Sphericity\np = {p_val:.2e}",
                  fontweight="bold", fontsize=15)
    sig_text = "Significant (p < 0.001)" if p_val < 0.001 else f"p = {p_val:.4f}"
    ax2.text(0, chi2 * 0.5, sig_text,
             ha="center", va="center", fontsize=14, fontweight="bold",
             color="white")
    ax2.grid(False)
    ax2.spines["top"].set_visible(False)
    ax2.spines["right"].set_visible(False)

    fig.suptitle("KMO and Bartlett's Test Results", fontsize=19, fontweight="bold")
    plt.tight_layout()
    save_fig("Fig04_KMO_Bartlett")
    plt.close()


def fig05_efa_loadings(efa_res: dict):
    loadings = efa_res["loadings"]
    fig, ax  = plt.subplots(figsize=(13, 9))
    im = ax.imshow(loadings.values.T, cmap="RdBu_r",
                   vmin=-1, vmax=1, aspect="auto")
    ax.set_xticks(range(len(loadings.index)))
    ax.set_xticklabels(loadings.index, rotation=45, ha="right",
                       fontsize=12, fontweight="bold")
    ax.set_yticks(range(len(loadings.columns)))
    ax.set_yticklabels(loadings.columns, fontsize=13, fontweight="bold")
    for i in range(loadings.shape[0]):
        for j in range(loadings.shape[1]):
            val = loadings.values[i, j]
            ax.text(i, j, f"{val:.2f}", ha="center", va="center",
                    fontsize=10, fontweight="bold",
                    color="white" if abs(val) > 0.5 else "black")
    plt.colorbar(im, ax=ax, label="Factor Loading")
    ax.set_title("EFA Factor Loading Matrix (Oblimin Rotation, ML Method)",
                 fontweight="bold", fontsize=16, pad=15)
    ax.grid(False)
    plt.tight_layout()
    save_fig("Fig05_EFA_Factor_Loadings")
    plt.close()


def fig06_cfa_model(cfa_res: dict):
    """Draw a simplified CFA path diagram."""
    fig, ax = plt.subplots(figsize=(14, 10))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.axis("off")
    ax.set_title("CFA Measurement Model Diagram (Eight Oddities Packaging Research)",
                 fontweight="bold", fontsize=16, pad=12)

    # Layout: IVs left, DVs right
    iv_coords  = {"RD": (1.5, 8), "AD": (1.5, 6), "ERD": (1.5, 4), "SM": (1.5, 2)}
    dv_coords  = {"CI": (8.5, 9), "CINT": (8.5, 7.5), "CC": (8.5, 6),
                  "VC": (8.5, 4), "PR": (8.5, 2.5)}
    path_map   = {"RD": ["CI"], "AD": ["CINT"], "ERD": ["CC"], "SM": ["VC", "PR"]}

    # Draw latent construct ovals
    for code, (cx, cy) in iv_coords.items():
        ellipse = mpatches.Ellipse((cx, cy), 1.8, 0.8,
                                   edgecolor="#2C3E50", facecolor="#D6EAF8",
                                   linewidth=2)
        ax.add_patch(ellipse)
        ax.text(cx, cy, f"{code}\n({CONSTRUCTS[code]['name']})",
                ha="center", va="center", fontsize=10, fontweight="bold")

    for code, (cx, cy) in dv_coords.items():
        ellipse = mpatches.Ellipse((cx, cy), 1.8, 0.8,
                                   edgecolor="#C0392B", facecolor="#FADBD8",
                                   linewidth=2)
        ax.add_patch(ellipse)
        ax.text(cx, cy, f"{code}\n({CONSTRUCTS[code]['name']})",
                ha="center", va="center", fontsize=10, fontweight="bold")

    # Draw arrows
    for iv, dvs in path_map.items():
        x1, y1 = iv_coords[iv]
        for dv in dvs:
            x2, y2 = dv_coords[dv]
            ax.annotate("", xy=(x2 - 0.9, y2), xytext=(x1 + 0.9, y1),
                        arrowprops=dict(arrowstyle="->", color="#2C3E50",
                                        lw=2.0))

    # Legend
    iv_patch = mpatches.Patch(facecolor="#D6EAF8", edgecolor="#2C3E50",
                               label="Independent Variable (IV)")
    dv_patch = mpatches.Patch(facecolor="#FADBD8", edgecolor="#C0392B",
                               label="Dependent Variable (DV)")
    ax.legend(handles=[iv_patch, dv_patch], loc="lower center",
              fontsize=12, frameon=True)
    plt.tight_layout()
    save_fig("Fig06_CFA_Model")
    plt.close()


def fig07_convergent_validity(cfa_res: dict):
    cr_ave = cfa_res["cr_ave"]
    fig, ax = plt.subplots(figsize=(12, 7))
    x     = np.arange(len(cr_ave))
    width = 0.35
    b1    = ax.bar(x - width / 2, cr_ave["CR"],  width, label="CR",
                   color="#2980B9", edgecolor="black")
    b2    = ax.bar(x + width / 2, cr_ave["AVE"], width, label="AVE",
                   color="#E74C3C", edgecolor="black")
    ax.axhline(0.70, color="#2980B9", linestyle="--", linewidth=1.2,
               label="CR threshold (0.70)")
    ax.axhline(0.50, color="#E74C3C", linestyle="--", linewidth=1.2,
               label="AVE threshold (0.50)")
    ax.set_xticks(x)
    ax.set_xticklabels(cr_ave["Code"], fontsize=13, fontweight="bold")
    ax.set_ylabel("Value", fontweight="bold", fontsize=14)
    ax.set_title("Convergent Validity: Composite Reliability & AVE",
                 fontweight="bold", fontsize=16)
    ax.set_ylim(0, 1.05)
    ax.legend(fontsize=12)
    ax.grid(False)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    for b in list(b1) + list(b2):
        ax.text(b.get_x() + b.get_width() / 2,
                b.get_height() + 0.01,
                f"{b.get_height():.3f}",
                ha="center", va="bottom", fontsize=10, fontweight="bold")
    plt.tight_layout()
    save_fig("Fig07_Convergent_Validity")
    plt.close()


def fig08_discriminant_validity(cfa_res: dict):
    fl    = cfa_res["fl_matrix"].astype(float)
    codes = fl.index.tolist()
    fig, ax = plt.subplots(figsize=(12, 10))
    im    = ax.imshow(fl.values, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(len(codes)))
    ax.set_xticklabels(codes, fontsize=13, fontweight="bold")
    ax.set_yticks(range(len(codes)))
    ax.set_yticklabels(codes, fontsize=13, fontweight="bold")
    for i in range(len(codes)):
        for j in range(len(codes)):
            val = fl.values[i, j]
            if not np.isnan(val):
                weight = "bold" if i == j else "normal"
                ax.text(j, i, f"{val:.3f}", ha="center", va="center",
                        fontsize=11, fontweight=weight,
                        color="white" if val > 0.6 else "black")
    plt.colorbar(im, ax=ax)
    ax.set_title("Discriminant Validity: Fornell-Larcker Criterion Matrix\n(Diagonal = √AVE; Off-diagonal = Correlations)",
                 fontweight="bold", fontsize=15)
    ax.grid(False)
    plt.tight_layout()
    save_fig("Fig08_Discriminant_Validity")
    plt.close()


def fig09_correlation_heatmap(corr_res: dict):
    corr = corr_res["corr_matrix"]
    mask = np.triu(np.ones_like(corr, dtype=bool), k=1)
    fig, ax = plt.subplots(figsize=(13, 10))
    sns.heatmap(
        corr, ax=ax, annot=True, fmt=".3f",
        cmap="RdBu_r", vmin=-1, vmax=1,
        linewidths=0.5, linecolor="white",
        annot_kws={"size": 12, "weight": "bold"},
        cbar_kws={"shrink": 0.8},
    )
    ax.set_title("Pearson Correlation Heatmap of Construct Scores",
                 fontweight="bold", fontsize=17, pad=12)
    ax.grid(False)
    ax.set_xticklabels(ax.get_xticklabels(),
                       rotation=45, ha="right", fontsize=12, fontweight="bold")
    ax.set_yticklabels(ax.get_yticklabels(),
                       rotation=0, fontsize=12, fontweight="bold")
    plt.tight_layout()
    save_fig("Fig09_Correlation_Heatmap")
    plt.close()


def fig10_regression_coefs(reg_res: dict):
    hyp = reg_res["hypothesis"]
    fig, ax = plt.subplots(figsize=(12, 7))
    colors  = ["#27AE60" if d == "Supported" else "#C0392B"
               for d in hyp["Decision"]]
    labels  = hyp["Hypothesis"]
    betas   = hyp["Std. Beta (β)"]
    bars    = ax.barh(labels, betas, color=colors,
                      edgecolor="black", linewidth=0.8)
    ax.axvline(0, color="black", linewidth=1.2)
    ax.set_xlabel("Standardised Beta Coefficient (β)", fontweight="bold", fontsize=14)
    ax.set_title("Multiple Regression Coefficients by Hypothesis",
                 fontweight="bold", fontsize=16)
    for b, v in zip(bars, betas):
        ax.text(v + 0.005, b.get_y() + b.get_height() / 2,
                f"{v:.3f}", va="center", fontsize=12, fontweight="bold")
    supported = mpatches.Patch(color="#27AE60", label="Supported")
    not_sup   = mpatches.Patch(color="#C0392B", label="Not Supported")
    ax.legend(handles=[supported, not_sup], fontsize=12)
    ax.grid(False)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    plt.tight_layout()
    save_fig("Fig10_Regression_Coefficients")
    plt.close()


def fig11_r2_comparison(reg_res: dict):
    mp    = reg_res["model_perf"]
    fig, ax = plt.subplots(figsize=(12, 7))
    colors  = ["#2980B9" if r2 >= 0.75 else "#F39C12" if r2 >= 0.60 else "#E74C3C"
               for r2 in mp["R²"]]
    bars    = ax.bar(mp["Hypothesis"], mp["R²"],
                     color=colors, edgecolor="black", linewidth=0.8)
    ax.axhline(0.75, linestyle="--", color="#27AE60", linewidth=1.5,
               label="Target lower (0.75)")
    ax.axhline(0.85, linestyle="--", color="#2980B9", linewidth=1.5,
               label="Target upper (0.85)")
    ax.set_ylim(0, 1.0)
    ax.set_ylabel("R² Value", fontweight="bold", fontsize=14)
    ax.set_title("R² Comparison Across Hypotheses",
                 fontweight="bold", fontsize=16)
    ax.legend(fontsize=12)
    ax.grid(False)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    for b, v in zip(bars, mp["R²"]):
        ax.text(b.get_x() + b.get_width() / 2,
                v + 0.005, f"{v:.3f}",
                ha="center", va="bottom", fontsize=12, fontweight="bold")
    plt.tight_layout()
    save_fig("Fig11_R2_Comparison")
    plt.close()


def fig12_hypothesis_testing(reg_res: dict):
    hyp   = reg_res["hypothesis"]
    fig, axes = plt.subplots(1, 2, figsize=(16, 7))

    # t-statistics
    ax  = axes[0]
    colors = ["#27AE60" if d == "Supported" else "#C0392B" for d in hyp["Decision"]]
    bars   = ax.barh(hyp["Hypothesis"], hyp["t-statistic"],
                     color=colors, edgecolor="black", linewidth=0.8)
    ax.axvline(1.96, color="black", linestyle="--", linewidth=1.5,
               label="Critical t (1.96)")
    ax.set_xlabel("t-statistic", fontweight="bold", fontsize=14)
    ax.set_title("Hypothesis Testing: t-Statistics",
                 fontweight="bold", fontsize=15)
    ax.legend(fontsize=12)
    ax.grid(False)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # p-values
    ax2 = axes[1]
    p_neg_log = [-np.log10(p + 1e-10) for p in hyp["p-value"]]
    bars2 = ax2.barh(hyp["Hypothesis"], p_neg_log,
                     color=colors, edgecolor="black", linewidth=0.8)
    ax2.axvline(-np.log10(0.05), color="black", linestyle="--", linewidth=1.5,
                label="p=0.05 threshold")
    ax2.set_xlabel("−log₁₀(p-value)", fontweight="bold", fontsize=14)
    ax2.set_title("Hypothesis Testing: Significance (−log₁₀ p)",
                  fontweight="bold", fontsize=15)
    ax2.legend(fontsize=12)
    ax2.grid(False)
    ax2.spines["top"].set_visible(False)
    ax2.spines["right"].set_visible(False)

    fig.suptitle("Hypothesis Testing Results (H1–H4)", fontsize=18, fontweight="bold")
    plt.tight_layout()
    save_fig("Fig12_Hypothesis_Testing")
    plt.close()


def fig13_thematic_map(qual_res: dict):
    theme_df = qual_res["theme_df"]
    fig, ax  = plt.subplots(figsize=(13, 9))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.axis("off")
    ax.set_title("Expert Interview Thematic Map\n(Northeast China Eight Oddities Packaging Design — SYNTHETIC DATA)",
                 fontweight="bold", fontsize=15, pad=12)

    # Central node
    centre = mpatches.FancyBboxPatch((3.8, 4.4), 2.4, 1.2,
                                     boxstyle="round,pad=0.1",
                                     facecolor="#2C3E50", edgecolor="white", linewidth=2)
    ax.add_patch(centre)
    ax.text(5, 5, "Eight Oddities\nPackaging Design",
            ha="center", va="center", fontsize=12, fontweight="bold", color="white")

    # Theme nodes
    positions = [(1.0, 8.5), (8.5, 8.5), (0.5, 5.0),
                 (9.0, 5.0), (1.5, 1.5), (8.0, 1.5)]
    colors_themes = ["#D6EAF8", "#FADBD8", "#D5F5E3",
                     "#FDEBD0", "#E8DAEF", "#D5D8DC"]
    themes_list = theme_df["Theme"].tolist()

    for i, (theme, (tx, ty)) in enumerate(zip(themes_list, positions)):
        box = mpatches.FancyBboxPatch((tx - 1.2, ty - 0.6), 2.4, 1.2,
                                      boxstyle="round,pad=0.1",
                                      facecolor=colors_themes[i % len(colors_themes)],
                                      edgecolor="#2C3E50", linewidth=1.5)
        ax.add_patch(box)
        short = theme.replace("Northeast Regional ", "NE ").replace(
            "& Visual Consistency", "")[:30]
        ax.text(tx, ty, short, ha="center", va="center",
                fontsize=9, fontweight="bold", wrap=True)
        ax.annotate("", xy=(5, 5), xytext=(tx, ty),
                    arrowprops=dict(arrowstyle="-", color="#7F8C8D",
                                   lw=1.2, linestyle="dashed"))

    plt.tight_layout()
    save_fig("Fig13_Thematic_Map")
    plt.close()


def fig14_theme_frequency(qual_res: dict):
    top_kw   = qual_res["top_keywords"]
    theme_df = qual_res["theme_df"]

    fig, axes = plt.subplots(1, 2, figsize=(16, 8))

    # Top keywords
    ax = axes[0]
    colors = plt.cm.Blues(np.linspace(0.4, 0.9, len(top_kw)))[::-1]
    ax.barh(top_kw["Keyword"], top_kw["Frequency"],
            color=colors, edgecolor="black", linewidth=0.6)
    ax.set_xlabel("Frequency", fontweight="bold", fontsize=14)
    ax.set_title("Top 25 Keywords — Expert Interviews\n(Synthetic Data)",
                 fontweight="bold", fontsize=14)
    ax.grid(False)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # Theme frequencies
    ax2  = axes[1]
    colors2 = ["#E74C3C", "#3498DB", "#2ECC71",
                "#F39C12", "#9B59B6", "#1ABC9C"]
    bars2 = ax2.bar(range(len(theme_df)), theme_df["Frequency"],
                    color=colors2[:len(theme_df)], edgecolor="black", linewidth=0.8)
    ax2.set_xticks(range(len(theme_df)))
    ax2.set_xticklabels(
        [t[:20] + "…" if len(t) > 20 else t for t in theme_df["Theme"]],
        rotation=25, ha="right", fontsize=11, fontweight="bold")
    ax2.set_ylabel("Keyword Frequency", fontweight="bold", fontsize=14)
    ax2.set_title("Theme Frequency Distribution\n(Synthetic Data)",
                  fontweight="bold", fontsize=14)
    ax2.grid(False)
    ax2.spines["top"].set_visible(False)
    ax2.spines["right"].set_visible(False)

    fig.suptitle("Qualitative Analysis — Keyword & Theme Frequencies",
                 fontsize=18, fontweight="bold")
    plt.tight_layout()
    save_fig("Fig14_Theme_Frequency")
    plt.close()


def fig15_research_framework():
    fig, ax = plt.subplots(figsize=(14, 10))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 10)
    ax.axis("off")
    ax.set_title("Integrated Research Framework\nNortheast China Eight Oddities Packaging Design Innovation",
                 fontweight="bold", fontsize=16, pad=14)

    def box(ax, x, y, w, h, text, fc="#D6EAF8", ec="#2C3E50", fs=12):
        rect = mpatches.FancyBboxPatch((x - w / 2, y - h / 2), w, h,
                                       boxstyle="round,pad=0.15",
                                       facecolor=fc, edgecolor=ec, linewidth=2)
        ax.add_patch(rect)
        ax.text(x, y, text, ha="center", va="center",
                fontsize=fs, fontweight="bold", color="#2C3E50",
                multialignment="center")

    def arrow(ax, x1, y1, x2, y2, label=""):
        ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                    arrowprops=dict(arrowstyle="->", color="#2C3E50", lw=2))
        if label:
            mx, my = (x1 + x2) / 2, (y1 + y2) / 2
            ax.text(mx + 0.1, my + 0.1, label,
                    fontsize=10, fontweight="bold", color="#E74C3C")

    # IV boxes
    iv_data = [
        ("Regional\nDesign (RD)", 2, 8),
        ("Anthropomorphic\nDesign (AD)", 2, 6),
        ("Emotional Resonance\nDesign (ERD)", 2, 4),
        ("Series\nModelling (SM)", 2, 2),
    ]
    for label, x, y in iv_data:
        box(ax, x, y, 3.0, 1.0, label, fc="#D6EAF8")

    # DV boxes
    dv_data = [
        ("Cultural\nIdentity (CI)", 11, 8.5),
        ("Consumer\nInterest (CINT)", 11, 7),
        ("Cultural\nConnection (CC)", 11, 5.5),
        ("Visual\nConsistency (VC)", 11, 4),
        ("Packaging\nRecognition (PR)", 11, 2.5),
    ]
    for label, x, y in dv_data:
        box(ax, x, y, 3.0, 1.0, label, fc="#FADBD8", ec="#C0392B")

    # Hypothesis arrows
    hyp_links = [
        (2, 8,  11, 8.5, "H1"),
        (2, 6,  11, 7.0, "H2"),
        (2, 4,  11, 5.5, "H3"),
        (2, 2,  11, 4.0, "H4a"),
        (2, 2,  11, 2.5, "H4b"),
    ]
    for x1, y1, x2, y2, lbl in hyp_links:
        arrow(ax, x1 + 1.5, y1, x2 - 1.5, y2, lbl)

    # Mediating box
    box(ax, 7, 5, 2.5, 7.5, "Mixed-Methods\nResearch\nFramework",
        fc="#D5F5E3", ec="#27AE60", fs=11)

    # Legend
    iv_p = mpatches.Patch(facecolor="#D6EAF8", edgecolor="#2C3E50",
                           label="Independent Variable")
    dv_p = mpatches.Patch(facecolor="#FADBD8", edgecolor="#C0392B",
                           label="Dependent Variable")
    ax.legend(handles=[iv_p, dv_p], loc="lower right", fontsize=12)
    plt.tight_layout()
    save_fig("Fig15_Research_Framework")
    plt.close()


def generate_all_figures(demo_tables, desc_df, rel_df, efa_res,
                         cfa_res, corr_res, reg_res, qual_res):
    log.info("=" * 60)
    log.info("STAGE 11: GENERATING FIGURES")
    log.info("=" * 60)
    fig01_demographics(demo_tables)
    fig02_descriptives(desc_df)
    fig03_cronbach(rel_df)
    fig04_kmo_bartlett(efa_res)
    fig05_efa_loadings(efa_res)
    fig06_cfa_model(cfa_res)
    fig07_convergent_validity(cfa_res)
    fig08_discriminant_validity(cfa_res)
    fig09_correlation_heatmap(corr_res)
    fig10_regression_coefs(reg_res)
    fig11_r2_comparison(reg_res)
    fig12_hypothesis_testing(reg_res)
    fig13_thematic_map(qual_res)
    fig14_theme_frequency(qual_res)
    fig15_research_framework()
    log.info("  All 15 figures saved (PNG + TIFF).")


# ═══════════════════════════════════════════════════════════════════════
# 12. EXCEL WORKBOOK
# ═══════════════════════════════════════════════════════════════════════

def _fmt_sheet(ws, wb):
    """Apply professional Excel formatting to a worksheet."""
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    header_fill = PatternFill("solid", fgColor="2C3E50")
    header_font = Font(bold=True, color="FFFFFF", size=11)
    body_font   = Font(size=10)
    thin        = Side(style="thin")
    border      = Border(left=thin, right=thin, top=thin, bottom=thin)
    centre      = Alignment(horizontal="center", vertical="center")

    for row_idx, row in enumerate(ws.iter_rows(), start=1):
        for cell in row:
            if row_idx == 1:
                cell.fill = header_fill
                cell.font = header_font
            else:
                cell.font = body_font
            cell.border = border
            cell.alignment = centre

    # Auto-width
    for col in ws.columns:
        max_len = 0
        col_ltr = get_column_letter(col[0].column)
        for cell in col:
            try:
                if cell.value:
                    max_len = max(max_len, len(str(cell.value)))
            except Exception:
                pass
        ws.column_dimensions[col_ltr].width = min(max_len + 4, 50)

    # Freeze header
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions


def export_excel(
    df_clean, demo_tables, desc_df, rel_df, efa_res,
    cfa_res, corr_res, reg_res, qual_res, dq_report
):
    log.info("=" * 60)
    log.info("STAGE 12: EXPORTING EXCEL WORKBOOK")
    log.info("=" * 60)
    from openpyxl import load_workbook

    out_path = PATHS["results"] / "Eight_Oddities_Research_Results.xlsx"

    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:

        # 1. Demographic_Analysis
        combined_demo = pd.concat(
            [tbl.assign(Category=title)
             for title, tbl in demo_tables.items()],
            ignore_index=True,
        )
        combined_demo.to_excel(writer, sheet_name="Demographic_Analysis", index=False)

        # 2. Descriptive_Statistics
        desc_df.to_excel(writer, sheet_name="Descriptive_Statistics", index=False)

        # 3. Reliability_Analysis
        rel_df.to_excel(writer, sheet_name="Reliability_Analysis", index=False)

        # 4. KMO_Bartlett_Test
        efa_res["kmo_bartlett"].to_excel(writer, sheet_name="KMO_Bartlett_Test", index=False)

        # 5. EFA_Results — loadings + variance
        efa_res["loadings"].reset_index().to_excel(
            writer, sheet_name="EFA_Results", index=False)
        wb   = writer.book
        ws   = wb["EFA_Results"]
        # Append variance table below loadings (leave 2 blank rows)
        start = len(efa_res["loadings"]) + 4
        ws.cell(start, 1, "Factor Variance Summary")
        for r_idx, row in efa_res["variance"].iterrows():
            for c_idx, val in enumerate(row):
                ws.cell(start + 1 + r_idx, c_idx + 1, val)

        # 6. CFA_Results
        cfa_res["fit_indices"].to_excel(writer, sheet_name="CFA_Results", index=False)

        # 7. Convergent_Validity
        cfa_res["cr_ave"].to_excel(writer, sheet_name="Convergent_Validity", index=False)

        # 8. Discriminant_Validity — FL matrix + HTMT
        cfa_res["fl_matrix"].reset_index().to_excel(
            writer, sheet_name="Discriminant_Validity", index=False)
        wb_ws = wb["Discriminant_Validity"]
        offset = len(cfa_res["fl_matrix"]) + 4
        wb_ws.cell(offset, 1, "HTMT Ratios")
        for r_idx, row in cfa_res["htmt"].iterrows():
            for c_idx, val in enumerate(row):
                wb_ws.cell(offset + 1 + r_idx, c_idx + 1, val)

        # 9. Correlation_Analysis
        corr_res["corr_matrix"].reset_index().to_excel(
            writer, sheet_name="Correlation_Analysis", index=False)

        # 10. Regression_Results
        reg_res["regression"].to_excel(writer, sheet_name="Regression_Results", index=False)

        # 11. Hypothesis_Testing
        reg_res["hypothesis"].to_excel(writer, sheet_name="Hypothesis_Testing", index=False)

        # 12. VIF_Analysis
        reg_res["vif"].to_excel(writer, sheet_name="VIF_Analysis", index=False)

        # 13. Qualitative_Themes
        qual_res["theme_df"].to_excel(writer, sheet_name="Qualitative_Themes", index=False)

        # 14. Cultural_Elements
        qual_res["cultural_df"].to_excel(writer, sheet_name="Cultural_Elements", index=False)

        # 15. Model_Performance
        reg_res["model_perf"].to_excel(writer, sheet_name="Model_Performance", index=False)

        # 16. Data_Quality_Report
        dq_df = pd.DataFrame(list(dq_report.items()), columns=["Metric", "Value"])
        dq_df["Value"] = dq_df["Value"].astype(str)
        dq_df.to_excel(writer, sheet_name="Data_Quality_Report", index=False)

    # Apply formatting
    from openpyxl import load_workbook as _lw
    wb2 = _lw(out_path)
    for ws_name in wb2.sheetnames:
        _fmt_sheet(wb2[ws_name], wb2)
    wb2.save(out_path)
    log.info(f"  Excel workbook saved: {out_path}")
    return out_path


# ═══════════════════════════════════════════════════════════════════════
# 13. SAVE CLEANED DATASETS & MODELS
# ═══════════════════════════════════════════════════════════════════════

def save_datasets_and_models(df_raw, df_clean, efa_res, reg_res):
    log.info("=" * 60)
    log.info("STAGE 13: SAVING DATASETS & MODELS")
    log.info("=" * 60)

    # Raw
    df_raw.to_excel(PATHS["dataset"] / "raw_dataset.xlsx", index=False)
    # Cleaned
    df_clean.to_excel(PATHS["dataset"] / "cleaned_dataset.xlsx", index=False)
    # Processed CSV
    df_clean.to_csv(PATHS["dataset"] / "processed_dataset.csv", index=False)

    # Qualitative
    qual_int = pd.DataFrame({
        "ExpertID"  : [f"E{i:02d}" for i in range(1, 16)],
        "Transcript": EXPERT_TRANSCRIPTS,
        "Note"      : ["SYNTHETIC" for _ in EXPERT_TRANSCRIPTS],
    })
    qual_int.to_excel(PATHS["qual"] / "interview_codes.xlsx", index=False)

    # EFA model
    with open(PATHS["models"] / "efa_model.pkl", "wb") as f:
        pickle.dump(efa_res["fa"], f)

    # Regression summary
    with open(PATHS["models"] / "regression_models.pkl", "wb") as f:
        pickle.dump(reg_res, f)

    log.info("  Datasets and models saved.")


# ═══════════════════════════════════════════════════════════════════════
# 14. INTERPRETATION SUMMARY
# ═══════════════════════════════════════════════════════════════════════

def print_interpretation(rel_df, reg_res, efa_res):
    hyp = reg_res["hypothesis"]
    log.info("")
    log.info("=" * 70)
    log.info("RESEARCH INTERPRETATION SUMMARY")
    log.info("=" * 70)
    log.info("")
    log.info("RELIABILITY")
    for _, row in rel_df.iterrows():
        alpha_key = "Cronbach's Alpha"
        alpha_v   = row[alpha_key]
        status_v  = row["Status"]
        code_v    = row["Code"]
        log.info(f"  {code_v:5s}: alpha = {alpha_v:.3f} -> {status_v}")
    log.info("")
    log.info("HYPOTHESIS TEST OUTCOMES")
    for _, row in hyp.iterrows():
        log.info(
            f"  {row['Hypothesis']:4s}: β={row['Std. Beta (β)']:+.3f}, "
            f"t={row['t-statistic']:.3f}, p={row['p-value']:.4f}, "
            f"R²={row['R²']:.3f} → {row['Decision']}"
        )
    log.info("")
    log.info("R² TARGET RANGE (0.75–0.85)")
    for _, row in hyp.iterrows():
        r2  = row["R²"]
        inr = 0.75 <= r2 <= 0.85
        log.info(
            f"  {row['Hypothesis']:4s}: R²={r2:.3f} "
            + ("✓ Within target" if inr else "— Outside target (see notes)")
        )
    log.info("")
    log.info("NOTE: R² from simple bivariate regressions (one IV → one DV).")
    log.info("      Simple regression R² is typically lower than multi-IV models.")
    log.info("      If R² falls below 0.75, consider including controls or")
    log.info("      examining composite IV models as a robustness check.")
    log.info("")
    log.info("KMO / BARTLETT")
    kmo = efa_res["kmo_model"]
    chi = efa_res["bartlett_chi2"]
    p   = efa_res["bartlett_p"]
    log.info(f"  KMO = {kmo:.3f} ({'Acceptable' if kmo >= 0.60 else 'Below acceptable'})")
    log.info(f"  Bartlett χ² = {chi:.2f}, p = {p:.4e}")
    log.info("=" * 70)


# ═══════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════

def main():
    start_time = datetime.datetime.now()
    log.info(f"Pipeline start: {start_time.isoformat()}")

    # Stage 2: Generate data
    df_raw = generate_synthetic_data()

    # Stage 3: Preprocess
    df_clean, dq_report = preprocess_data(df_raw)

    # Stage 4: Descriptive statistics
    desc_res  = descriptive_statistics(df_clean)
    demo_tables = desc_res["demographic"]
    desc_df     = desc_res["item_descriptives"]

    # Stage 5: Reliability
    rel_df = reliability_analysis(df_clean)

    # Stage 6: EFA
    efa_res = run_efa(df_clean)

    # Stage 7: CFA
    cfa_res = run_cfa(df_clean, rel_df)

    # Stage 8: Correlation
    corr_res = correlation_analysis(df_clean)

    # Stage 9: Regression & Hypotheses
    reg_res = regression_and_hypothesis(df_clean)

    # Stage 10: Qualitative
    qual_res = qualitative_analysis()

    # Stage 11: Figures
    generate_all_figures(
        demo_tables, desc_df, rel_df, efa_res,
        cfa_res, corr_res, reg_res, qual_res
    )

    # Stage 12: Excel export
    export_excel(
        df_clean, demo_tables, desc_df, rel_df, efa_res,
        cfa_res, corr_res, reg_res, qual_res, dq_report
    )

    # Stage 13: Save datasets & models
    save_datasets_and_models(df_raw, df_clean, efa_res, reg_res)

    # Stage 14: Interpretation
    print_interpretation(rel_df, reg_res, efa_res)

    # Thematic analysis workbook
    qual_res["theme_df"].to_excel(
        PATHS["qual"] / "thematic_analysis.xlsx", index=False)

    end_time = datetime.datetime.now()
    duration = (end_time - start_time).total_seconds()
    log.info(f"\nPipeline complete in {duration:.1f} seconds.")
    log.info(f"All outputs written to: {BASE}")


if __name__ == "__main__":
    main()
