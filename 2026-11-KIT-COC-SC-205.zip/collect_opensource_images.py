"""
Collect Open-Source (Wikimedia Commons CC/Public Domain) reference images
for the Northeast China Folk Customs "Eight Oddities" (东北八大怪).
Downloads images, records license and author attribution, and produces a summary table.
"""
import os
import json
import urllib.request
import urllib.parse
from pathlib import Path
import pandas as pd

SAVE_DIR = Path(r"d:\Alan christo\November2026\2026-11-KIT-COC-SC-205\Eight_Oddities_Research\dataset\opensource_images")
SAVE_DIR.mkdir(parents=True, exist_ok=True)

USER_AGENT = "AntigravityResearchCollector/1.0 (academic packaging research; mailto:research@example.edu)"

SEARCH_QUERIES = [
    {
        "oddity_id": 1,
        "title_cn": "窗户纸糊在外",
        "title_en": "Window Paper Pasted on the Outside",
        "keywords": ["Chinese paper window lattice", "traditional Chinese window paper", "Chinese lattice window paper"],
        "filename": "oddity_01_window_paper.jpg"
    },
    {
        "oddity_id": 2,
        "title_cn": "姑娘叼个大烟袋",
        "title_en": "Young Women Smoking Big Tobacco Pipe",
        "keywords": ["traditional Chinese tobacco pipe", "Chinese long smoking pipe", "Chinese brass pipe"],
        "filename": "oddity_02_tobacco_pipe.jpg"
    },
    {
        "oddity_id": 3,
        "title_cn": "养个孩子吊起来",
        "title_en": "Babies Cradled in Hanging Cradle (Youche)",
        "keywords": ["hanging cradle baby traditional", "wooden baby cradle suspended", "traditional baby cradle"],
        "filename": "oddity_03_hanging_cradle.jpg"
    },
    {
        "oddity_id": 4,
        "title_cn": "吉祥喜庆粘豆包",
        "title_en": "Festive Sticky Bean Buns (Zhandoubao)",
        "keywords": ["Zhandoubao", "Chinese red bean steamed bun", "steamed bean bun Chinese"],
        "filename": "oddity_04_sticky_bean_buns.jpg"
    },
    {
        "oddity_id": 5,
        "title_cn": "翻穿皮袄毛朝外",
        "title_en": "Fur Coats Worn Inside-Out (Fur Outside)",
        "keywords": ["traditional sheepskin coat", "shearling coat fur outside", "traditional winter fur coat"],
        "filename": "oddity_05_fur_coat.jpg"
    },
    {
        "oddity_id": 6,
        "title_cn": "大缸小缸腌酸菜",
        "title_en": "Sauerkraut in Earthenware Jars (Suancai)",
        "keywords": ["Chinese pickle jar earthenware", "fermentation crock earthenware jar", "Chinese sauerkraut suancai"],
        "filename": "oddity_06_sauerkraut_jar.jpg"
    },
    {
        "oddity_id": 7,
        "title_cn": "冬季马车比火车快",
        "title_en": "Winter Horse-Drawn Sled (Pali) on Snow",
        "keywords": ["horse-drawn sledge snow winter", "horse drawn sled winter", "horse sledge snow"],
        "filename": "oddity_07_horse_sled.jpg"
    },
    {
        "oddity_id": 8,
        "title_cn": "狗皮帽子头上戴",
        "title_en": "Fur Trapper Hat with Ear Flaps",
        "keywords": ["fur trapper hat ear flaps", "winter fur hat ear flaps", "traditional winter fur hat"],
        "filename": "oddity_08_fur_hat.jpg"
    }
]

def search_wikimedia(query):
    base_url = "https://commons.wikimedia.org/w/api.php"
    params = {
        "action": "query",
        "format": "json",
        "generator": "search",
        "gsrsearch": query,
        "gsrnamespace": "6",  # File namespace
        "gsrlimit": "5",
        "prop": "imageinfo",
        "iiprop": "url|extmetadata|size"
    }
    url = f"{base_url}?{urllib.parse.urlencode(params)}"
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=12) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            pages = data.get("query", {}).get("pages", {})
            results = []
            for page_id, page_info in pages.items():
                img_info_list = page_info.get("imageinfo", [])
                if not img_info_list:
                    continue
                info = img_info_list[0]
                meta = info.get("extmetadata", {})
                
                # Check file type
                file_url = info.get("url", "")
                if not any(file_url.lower().endswith(ext) for ext in [".jpg", ".jpeg", ".png"]):
                    # try thumburl
                    file_url = info.get("thumburl", file_url)
                
                # Only keep image files
                if any(file_url.lower().endswith(ext) for ext in [".jpg", ".jpeg", ".png"]):
                    license_name = meta.get("LicenseShortName", {}).get("value", "Creative Commons / Public Domain")
                    artist = meta.get("Artist", {}).get("value", "Wikimedia Contributor")
                    # Clean html from artist
                    import re
                    clean_artist = re.sub(r"<[^>]+>", "", artist).strip()[:50]
                    results.append({
                        "title": page_info.get("title", ""),
                        "url": file_url,
                        "license": license_name,
                        "artist": clean_artist if clean_artist else "Wikimedia Commons Contributor",
                        "width": info.get("width", 0),
                        "height": info.get("height", 0)
                    })
            return results
    except Exception as e:
        print(f"Error querying {query}: {e}")
        return []

records = []
for item in SEARCH_QUERIES:
    print(f"Searching for Oddity {item['oddity_id']}: {item['title_en']}...")
    found = False
    for kw in item["keywords"]:
        res = search_wikimedia(kw)
        if res:
            # Pick first valid image
            img_candidate = res[0]
            download_url = img_candidate["url"]
            target_path = SAVE_DIR / item["filename"]
            
            try:
                # Download with user-agent
                dl_req = urllib.request.Request(download_url, headers={"User-Agent": USER_AGENT})
                with urllib.request.urlopen(dl_req, timeout=15) as r_in, open(target_path, "wb") as f_out:
                    f_out.write(r_in.read())
                
                print(f"  [OK] Saved {item['filename']} ({img_candidate['license']}) from {download_url[:60]}...")
                records.append({
                    "Oddity_ID": item["oddity_id"],
                    "Title_Chinese": item["title_cn"],
                    "Title_English": item["title_en"],
                    "Local_Filename": item["filename"],
                    "Local_Path": str(target_path),
                    "License": img_candidate["license"],
                    "Attribution_Author": img_candidate["artist"],
                    "Source_URL": download_url,
                    "Wikimedia_Title": img_candidate["title"]
                })
                found = True
                break
            except Exception as e:
                print(f"  Failed downloading {download_url}: {e}")
                continue
    if not found:
        print(f"  [Warning] No image found for {item['title_en']}")

# Save table to Excel and JSON
df = pd.DataFrame(records)
excel_path = SAVE_DIR / "opensource_images_manifest.xlsx"
df.to_excel(excel_path, index=False)
json_path = SAVE_DIR / "opensource_images_manifest.json"
df.to_json(json_path, orient="records", indent=2)

print("\n=== SUMMARY ===")
print(f"Successfully collected {len(records)} of {len(SEARCH_QUERIES)} open-source images.")
print(f"Saved manifest to: {excel_path}")
