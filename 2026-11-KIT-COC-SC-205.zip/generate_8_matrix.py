"""
Generate a comprehensive 8-panel visual design matrix for the
Northeast China Folk Customs "Eight Oddities" (东北八大怪) Packaging Design Innovation.
Combines generated product photography with structured visual design blueprints for all 8 oddities.
"""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
from PIL import Image
import numpy as np

plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.weight"] = "bold"

ODDITIES = [
    {
        "num": 1,
        "title": "Window Paper on Outside",
        "pinyin": "Chuang Hu Zhi Hu Zai Wai",
        "concept": "Lattice Window Gift Box",
        "packaging": "Octagonal die-cut rigid box with translucent frosted vellum",
        "palette": ["#F5F5DC", "#B22222", "#D4AF37", "#2F4F4F"],
        "motifs": "Snowflake paper-cut, pine wood lattice, warm interior lantern glow",
        "mascot": "Snow Rabbit in padded coat peeking through paper window"
    },
    {
        "num": 2,
        "title": "Women Smoking Long Pipe",
        "pinyin": "Gu Niang Diao Ge Da Yan Dai",
        "concept": "Slender Cylindrical Canister",
        "packaging": "Matte-black metal canister with gold foil & red silk tassel",
        "palette": ["#1A1A1A", "#C0392B", "#D4AF37", "#F0E68C"],
        "motifs": "Long brass pipe, jade mouthpiece, curling smoke filigree",
        "mascot": "Retro-modern folk maiden with traditional hair bun and pipe",
        "img_path": r"d:\Alan christo\November2026\2026-11-KIT-COC-SC-205\Eight_Oddities_Research\figures\oddity_02_long_pipe.jpg"
    },
    {
        "num": 3,
        "title": "Cradle Hanging from Ceiling",
        "pinyin": "Yang Ge Hai Zi Diao Qi Lai",
        "concept": "Suspended Cradle Family Box",
        "packaging": "Curved birch-bark nesting carton with braided hemp handle",
        "palette": ["#E8D8C8", "#8B4513", "#CD853F", "#FFF8DC"],
        "motifs": "Suspended birch cradle (Youche), roof beams, handwoven quilts",
        "mascot": "Sleeping baby cub swaddled in red-and-green floral quilt"
    },
    {
        "num": 4,
        "title": "Festive Sticky Bean Buns",
        "pinyin": "Ji Xiang Xi Qing Zhan Dou Bao",
        "concept": "Snack Box & Steamer Pouches",
        "packaging": "Cubic confectionery carton with clear steam die-cut window",
        "palette": ["#F4D03F", "#922B21", "#E67E22", "#FFFFFF"],
        "motifs": "Steamed glutinous millet buns, adzuki paste, steam swirls",
        "mascot": "Chubby anthropomorphic golden bean bun character with rosy cheeks"
    },
    {
        "num": 5,
        "title": "Fur Coat Worn Fur-Out",
        "pinyin": "Fan Chuan Pi Ao Mao Chao Wai",
        "concept": "Embossed Winter Shearling Box",
        "packaging": "Textured faux-shearling carton with saddle-stitch leather trim",
        "palette": ["#FDFEFE", "#8B5A2B", "#5D6D7E", "#2C3E50"],
        "motifs": "Inverted sheepskin fleece, leather toggles, winter snowflakes",
        "mascot": "Little polar tiger bundled in an oversized fur-out sheepskin coat"
    },
    {
        "num": 6,
        "title": "Sauerkraut Earthenware Jars",
        "pinyin": "Da Gang Xiao Gang Yan Suan Cai",
        "concept": "Glazed Ceramic Crock & Box",
        "packaging": "Two-tone glazed stoneware jar with kraft wrap & outer box",
        "palette": ["#4A3728", "#556B2F", "#D2B48C", "#8FBC8F"],
        "motifs": "Glazed fermentation vat (Dagang), cabbage leaves, cellar stones",
        "mascot": "Old cellar master hedgehog salting crisp winter cabbages",
        "img_path": r"d:\Alan christo\November2026\2026-11-KIT-COC-SC-205\Eight_Oddities_Research\figures\oddity_06_sauerkraut_vat.jpg"
    },
    {
        "num": 7,
        "title": "Horse Sled Faster Than Trains",
        "pinyin": "Dong Ji Ma Che Bi Huo Che Kuai",
        "concept": "Dynamic Winter Sled Gift Set",
        "packaging": "Horizontal sliding drawer box with silver ice-runner accents",
        "palette": ["#1B4F72", "#C0392B", "#AED6F1", "#F4F6F7"],
        "motifs": "Galloping horse, wooden sledge (Pali), icy river trails, steam train",
        "mascot": "Spirited winter pony pulling a festive wooden sleigh loaded with gifts"
    },
    {
        "num": 8,
        "title": "Dog-Skin Ear-Flap Winter Hat",
        "pinyin": "Gou Pi Mao Zi Tou Shang Dai",
        "concept": "Folding Ear-Flap Mascot Box",
        "packaging": "Cube retail box with die-cut folding ear flaps on the top lid",
        "palette": ["#A0522D", "#2E4053", "#C0392B", "#F5B041"],
        "motifs": "Classic trapper ear-flaps, chin straps, Dongbei floral jacket",
        "mascot": "Iconic Dongbei folk boy wearing the fluffy trapper hat and smiling"
    }
]

fig = plt.figure(figsize=(22, 14), dpi=300)
fig.patch.set_facecolor("#FAF8F5")

plt.suptitle(
    "Northeast China Folk Customs 'Eight Oddities' (Dongbei Ba Da Guai) Packaging Design Innovation System",
    fontsize=24, fontweight="bold", y=0.98, color="#1A1A1A"
)

# 2 rows x 4 columns grid
for idx, odd in enumerate(ODDITIES):
    ax = fig.add_subplot(2, 4, idx + 1)
    ax.set_facecolor("#FFFFFF")
    
    # Outer border
    rect = mpatches.FancyBboxPatch(
        (0.02, 0.02), 0.96, 0.96,
        boxstyle="round,pad=0.03",
        facecolor="#FFFFFF",
        edgecolor="#2C3E50",
        linewidth=2.0
    )
    ax.add_patch(rect)
    
    # Header bar
    header = mpatches.FancyBboxPatch(
        (0.04, 0.84), 0.92, 0.12,
        boxstyle="round,pad=0.01",
        facecolor="#C0392B",
        edgecolor="#800000",
        linewidth=1.2
    )
    ax.add_patch(header)
    
    # Title text
    ax.text(
        0.50, 0.90, f"Oddity {odd['num']}: {odd['title']}",
        ha="center", va="center", color="#FFFFFF",
        fontsize=14, fontweight="bold"
    )
    ax.text(
        0.50, 0.81, odd["pinyin"],
        ha="center", va="center", color="#2C3E50",
        fontsize=9, fontstyle="italic", fontweight="bold"
    )
    
    # Image or Visual Placeholder
    if "img_path" in odd and os.path.exists(odd["img_path"]):
        try:
            img = Image.open(odd["img_path"])
            ax_in = ax.inset_axes([0.10, 0.45, 0.80, 0.32])
            ax_in.imshow(img)
            ax_in.axis("off")
            ax_in.set_title("Rendered 3D Packaging", fontsize=9, fontweight="bold", pad=2)
        except Exception:
            pass
    else:
        # Styled concept graphic card
        concept_box = mpatches.FancyBboxPatch(
            (0.10, 0.45), 0.80, 0.32,
            boxstyle="round,pad=0.02",
            facecolor="#F4ECE1",
            edgecolor="#C0392B",
            linestyle="--",
            linewidth=1.5
        )
        ax.add_patch(concept_box)
        ax.text(
            0.50, 0.63, f"Concept Design:\n{odd['concept']}",
            ha="center", va="center", color="#800000",
            fontsize=11, fontweight="bold"
        )
        ax.text(
            0.50, 0.51, f"Mascot: {odd['mascot'][:32]}...",
            ha="center", va="center", color="#555555",
            fontsize=8, fontweight="bold"
        )
    
    # Design Specifications
    y_text = 0.40
    ax.text(0.08, y_text, "Structure:", fontsize=9, fontweight="bold", color="#1A1A1A")
    ax.text(0.08, y_text - 0.05, f"{odd['packaging']}", fontsize=8, color="#333333", wrap=True)
    
    ax.text(0.08, y_text - 0.12, "Key Cultural Motifs:", fontsize=9, fontweight="bold", color="#1A1A1A")
    ax.text(0.08, y_text - 0.17, f"{odd['motifs']}", fontsize=8, color="#555555")
    
    # Color Palette Swatches
    ax.text(0.08, y_text - 0.24, "Palette:", fontsize=9, fontweight="bold", color="#1A1A1A")
    for s_idx, hex_c in enumerate(odd["palette"]):
        swatch = mpatches.Rectangle(
            (0.28 + s_idx * 0.14, y_text - 0.26), 0.10, 0.05,
            facecolor=hex_c, edgecolor="#333333", linewidth=0.8
        )
        ax.add_patch(swatch)
        
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

plt.tight_layout(rect=[0, 0.02, 1, 0.96])
out_png = r"d:\Alan christo\November2026\2026-11-KIT-COC-SC-205\Eight_Oddities_Research\figures\PNG\Eight_Oddities_8_Design_Matrix.png"
out_tiff = r"d:\Alan christo\November2026\2026-11-KIT-COC-SC-205\Eight_Oddities_Research\figures\TIFF\Eight_Oddities_8_Design_Matrix.tiff"
plt.savefig(out_png, dpi=300, facecolor=fig.get_facecolor(), bbox_inches="tight")
plt.savefig(out_tiff, dpi=300, facecolor=fig.get_facecolor(), bbox_inches="tight")
print(f"Generated 8-panel visual matrix: {out_png}")
