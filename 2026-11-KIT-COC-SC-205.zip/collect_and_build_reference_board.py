"""
Download and assemble open-source reference images from Wikimedia Commons
for all 8 Northeast China Folk Customs ("Eight Oddities" / 东北八大怪).
Uses Wikimedia Commons 800px thumburl for fast, high-quality downloads.
Saves images, manifests (Excel + JSON), and builds a publication-grade reference board.
"""
import os
import json
import re
import urllib.request
import urllib.parse
from pathlib import Path
import pandas as pd
from PIL import Image
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

BASE_DIR = Path(r"d:\Alan christo\November2026\2026-11-KIT-COC-SC-205\Eight_Oddities_Research")
SAVE_DIR = BASE_DIR / "dataset" / "opensource_images"
FIG_PNG  = BASE_DIR / "figures" / "PNG"
FIG_TIFF = BASE_DIR / "figures" / "TIFF"
SAVE_DIR.mkdir(parents=True, exist_ok=True)
FIG_PNG.mkdir(parents=True, exist_ok=True)
FIG_TIFF.mkdir(parents=True, exist_ok=True)

USER_AGENT = "AntigravityResearchCollector/1.0 (academic open packaging study; mailto:contact@research.edu)"

QUERIES = [
    {
        "oddity_id": 1,
        "title_cn": "窗户纸糊在外",
        "title_en": "Window Paper on Outside",
        "query": "lattice window China",
        "filename": "oddity_01_window_paper.jpg",
        "cultural_context": "Pasting thick oiled paper on the exterior of wooden window lattices to withstand -30°C Siberian blizzards without being blown inward."
    },
    {
        "oddity_id": 2,
        "title_cn": "姑娘叼个大烟袋",
        "title_en": "Women Smoking Long Pipe",
        "query": "tobacco pipe China",
        "filename": "oddity_02_tobacco_pipe.jpg",
        "cultural_context": "Long brass, jade-tipped smoking pipes held by folk women to repel mountain insects, warm hands, and socialize around the heated kang."
    },
    {
        "oddity_id": 3,
        "title_cn": "养个孩子吊起来",
        "title_en": "Babies in Suspended Cradle",
        "query": "baby cradle wooden",
        "filename": "oddity_03_hanging_cradle.jpg",
        "cultural_context": "The 'Youche' suspended from ceiling rafters to keep babies elevated from ground dampness, cold drafts, and predatory wildlife."
    },
    {
        "oddity_id": 4,
        "title_cn": "吉祥喜庆粘豆包",
        "title_en": "Festive Sticky Bean Buns",
        "query": "steamed bun",
        "filename": "oddity_04_sticky_bean_buns.jpg",
        "cultural_context": "Golden glutinous millet buns stuffed with sweet red bean paste, steamed in late autumn and naturally frozen outdoors as a winter calorie staple."
    },
    {
        "oddity_id": 5,
        "title_cn": "翻穿皮袄毛朝外",
        "title_en": "Fur Coats Worn Inside-Out",
        "query": "sheepskin coat",
        "filename": "oddity_05_fur_coat.jpg",
        "cultural_context": "Sheepskin overcoats worn with coarse fleece facing outward so driven snow easily shakes off without soaking through the leather."
    },
    {
        "oddity_id": 6,
        "title_cn": "大缸小缸腌酸菜",
        "title_en": "Sauerkraut in Earthenware Jars",
        "query": "earthenware jar",
        "filename": "oddity_06_sauerkraut_jar.jpg",
        "cultural_context": "Large stoneware crocks (Dagang) fermenting whole Chinese cabbages in salt brine to preserve vitamin-rich vegetables across long freezing winters."
    },
    {
        "oddity_id": 7,
        "title_cn": "冬季马车比火车快",
        "title_en": "Horse Sled Faster than Trains",
        "query": "horse sled snow",
        "filename": "oddity_07_horse_sled.jpg",
        "cultural_context": "Traditional wooden sledges ('Pali') skimming over frozen rivers and packed snowbanks faster than early steam locomotives through drifted mountain tracks."
    },
    {
        "oddity_id": 8,
        "title_cn": "狗皮帽子头上戴",
        "title_en": "Fur Trapper Hat with Ear Flaps",
        "query": "ushanka",
        "filename": "oddity_08_fur_hat.jpg",
        "cultural_context": "Thick fur winter hats with foldable ear-flaps and chin straps (Goupi Maozi), essential protective headgear against frostbite in sub-zero Manchurian winds."
    }
]

records = []
for item in QUERIES:
    print(f"Downloading Oddity {item['oddity_id']}: {item['title_en']}...")
    url = f"https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search&gsrsearch={urllib.parse.quote(item['query'])}&gsrnamespace=6&gsrlimit=3&prop=imageinfo&iiprop=url|extmetadata&iiurlwidth=800"
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read().decode("utf-8"))
            pages = list(data.get("query", {}).get("pages", {}).values())
            
            for p in pages:
                if "imageinfo" not in p:
                    continue
                info = p["imageinfo"][0]
                dl_url = info.get("thumburl", info.get("url", ""))
                orig_url = info.get("url", dl_url)
                
                meta = info.get("extmetadata", {})
                license_name = meta.get("LicenseShortName", {}).get("value", "CC BY-SA / Public Domain")
                artist_raw = meta.get("Artist", {}).get("value", "Wikimedia Contributor")
                artist = re.sub(r"<[^>]+>", "", artist_raw).strip()[:40] or "Wikimedia Commons Contributor"
                
                target_file = SAVE_DIR / item["filename"]
                dl_req = urllib.request.Request(dl_url, headers={"User-Agent": USER_AGENT})
                with urllib.request.urlopen(dl_req, timeout=12) as in_f, open(target_file, "wb") as out_f:
                    out_f.write(in_f.read())
                
                file_size_kb = round(os.path.getsize(target_file) / 1024, 1)
                print(f"  [OK] Saved {item['filename']} ({file_size_kb} KB) | License: {license_name} | Author: {artist}")
                records.append({
                    "Oddity_ID": item["oddity_id"],
                    "Title_Chinese": item["title_cn"],
                    "Title_English": item["title_en"],
                    "Search_Query": item["query"],
                    "Local_Filename": item["filename"],
                    "Local_Path": str(target_file),
                    "File_Size_KB": file_size_kb,
                    "License": license_name,
                    "Author_Attribution": artist,
                    "Source_URL": orig_url,
                    "Cultural_Context": item["cultural_context"]
                })
                break
    except Exception as e:
        print(f"  [Error] {item['title_en']}: {e}")

# Save manifests
df = pd.DataFrame(records)
excel_path = SAVE_DIR / "opensource_images_manifest.xlsx"
json_path = SAVE_DIR / "opensource_images_manifest.json"
df.to_excel(excel_path, index=False)
df.to_json(json_path, orient="records", indent=2)
print(f"\nManifests saved to Excel and JSON ({len(records)} items).")

# Generate 8-panel composite reference board
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.weight"] = "bold"

fig = plt.figure(figsize=(22, 14), dpi=300)
fig.patch.set_facecolor("#FAF8F5")

plt.suptitle(
    "Open-Source Cultural Reference Images: Northeast China 'Eight Oddities' (Dongbei Ba Da Guai)",
    fontsize=22, fontweight="bold", y=0.98, color="#1A1A1A"
)

for idx, rec in enumerate(records):
    ax = fig.add_subplot(2, 4, idx + 1)
    ax.set_facecolor("#FFFFFF")
    
    # Outer card
    rect = mpatches.FancyBboxPatch(
        (0.02, 0.02), 0.96, 0.96,
        boxstyle="round,pad=0.03",
        facecolor="#FFFFFF",
        edgecolor="#2C3E50",
        linewidth=2.0
    )
    ax.add_patch(rect)
    
    # Title badge
    badge = mpatches.FancyBboxPatch(
        (0.04, 0.86), 0.92, 0.10,
        boxstyle="round,pad=0.01",
        facecolor="#C0392B",
        edgecolor="#800000",
        linewidth=1.0
    )
    ax.add_patch(badge)
    ax.text(
        0.50, 0.91, f"Oddity {rec['Oddity_ID']}: {rec['Title_English']}",
        ha="center", va="center", color="#FFFFFF",
        fontsize=11, fontweight="bold"
    )
    
    # Display downloaded photo
    img_path = Path(rec["Local_Path"])
    if img_path.exists() and os.path.getsize(img_path) > 0:
        try:
            im = Image.open(img_path)
            ax_in = ax.inset_axes([0.08, 0.38, 0.84, 0.46])
            ax_in.imshow(im)
            ax_in.axis("off")
        except Exception:
            pass
            
    # Text metadata
    ax.text(0.06, 0.32, f"License: {rec['License']}", fontsize=9, fontweight="bold", color="#27AE60")
    ax.text(0.06, 0.27, f"Attribution: {rec['Author_Attribution']}", fontsize=8, color="#555555")
    ax.text(0.06, 0.21, "Cultural Context:", fontsize=8, fontweight="bold", color="#2C3E50")
    
    # Wrap context text
    context_words = rec["Cultural_Context"].split()
    lines = []
    curr = []
    for w in context_words:
        curr.append(w)
        if len(" ".join(curr)) > 36:
            lines.append(" ".join(curr))
            curr = []
    if curr:
        lines.append(" ".join(curr))
    
    for l_idx, line in enumerate(lines[:3]):
        ax.text(0.06, 0.16 - l_idx * 0.045, line, fontsize=7.5, color="#333333")
        
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

plt.tight_layout(rect=[0, 0.02, 1, 0.96])
board_png = FIG_PNG / "Eight_Oddities_Opensource_Reference_Board.png"
board_tiff = FIG_TIFF / "Eight_Oddities_Opensource_Reference_Board.tiff"
plt.savefig(board_png, dpi=300, facecolor=fig.get_facecolor(), bbox_inches="tight")
plt.savefig(board_tiff, dpi=300, facecolor=fig.get_facecolor(), bbox_inches="tight")
print(f"Reference board saved to: {board_png}")
